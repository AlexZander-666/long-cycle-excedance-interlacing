import LongCycleBounds.SixCutoffMoments

noncomputable section
namespace LongCycleBounds.SixCutoff
open Real Finset FixedCutoff Band

/-- At radius at least thirteen the five factorial terms have a uniform quintic envelope. -/
theorem quintic_majorant {R : ℝ} (hr : 13 ≤ R) :
    R+R^2/2+R^3/6+R^4/24+R^5/120 ≤ (21913/1713660:ℝ)*R^5 := by
  have h1 : 13*R ≤ R^2 := by nlinarith [mul_nonneg (sub_nonneg.mpr hr) (show 0 ≤ R by linarith)]
  have h2 : 13*R^2 ≤ R^3 := by nlinarith [mul_nonneg (sub_nonneg.mpr hr) (sq_nonneg R)]
  have h3 : 13*R^3 ≤ R^4 := by nlinarith [mul_nonneg (sub_nonneg.mpr hr) (pow_nonneg (show 0 ≤ R by linarith) 3)]
  have h4 : 13*R^4 ≤ R^5 := by nlinarith [mul_nonneg (sub_nonneg.mpr hr) (pow_nonneg (show 0≤R by linarith) 4)]
  linarith only [h1,h2,h3,h4]

theorem factorial_budget (b : ℕ → ℝ) {r R : ℝ} (hr : 0 ≤ r) (hR : 13 ≤ R)
    (bounds : ∀ i, 1 ≤ i → i ≤ 5 → |b i| ≤ r/i.factorial) :
    cost b R 5 ≤ (21913/1713660:ℝ)*r*R^5 := by
  have rr : 0 ≤ R := by linarith
  have term (i : ℕ) (lo : 1 ≤ i) (hi : i ≤ 5) :=
    mul_le_mul_of_nonneg_right (bounds i lo hi) (pow_nonneg rr i)
  have a := term 1 (by decide) (by decide)
  have b2 := term 2 (by decide) (by decide)
  have c := term 3 (by decide) (by decide)
  have d := term 4 (by decide) (by decide)
  have e := term 5 (by decide) (by decide)
  norm_num [Nat.factorial] at a b2 c d e
  simp only [cost,sum_range_succ,sum_range_zero,zero_add,Nat.reduceAdd,pow_one]
  linarith only [a,b2,c,d,e,mul_le_mul_of_nonneg_left (quintic_majorant hR) hr]

theorem middle_profile_cost {w : ℕ → ℝ} (w1 : w 1 = 0) (unit : ∀ i, w i ∈ Set.Icc (0:ℝ) 1)
    {x R : ℝ} (hx : 0 ≤ x) (hR : 13 ≤ R) :
    cost (fun a ↦ tiltCoefficient w a x) R 5 ≤ (21913/1713660:ℝ)*exp (-x)*R^5 :=
  factorial_budget _ (exp_pos _).le hR (fun _ ↦ tilt_factorial w1 unit hx)

theorem middle_drift_cost {w : ℕ → ℝ} (unit : ∀ i, w i ∈ Set.Icc (0:ℝ) 1)
    {x R : ℝ} (hx : 0 ≤ x) (hR : 13 ≤ R) :
    cost (fun a ↦ drift w a x) R 5 ≤ (21913/1713660:ℝ)*exp (-x)*R^5 :=
  factorial_budget _ (exp_pos _).le hR (fun _ ↦ drift_factorial unit hx)

#print axioms middle_profile_cost
#print axioms middle_drift_cost
end LongCycleBounds.SixCutoff
