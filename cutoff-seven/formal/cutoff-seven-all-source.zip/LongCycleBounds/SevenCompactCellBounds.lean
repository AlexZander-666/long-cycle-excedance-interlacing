import LongCycleBounds.SevenCompactCellReal

noncomputable section
namespace LongCycleBounds.SevenCutoff
open Real Finset FixedCutoff PoleBridge Band MarkedTwo LongCycleFinite.K7CompactCert
open FiveCutoff (roundUp_ge pi_enclosure)

theorem cell_drift {c : Cell} (hc : c.Valid) {x : ℝ} (xa : (c.a : ℝ) ≤ x)
    (xb : x ≤ (c.b : ℝ)) (rLo : (c.rLo:ℝ) ≤ exp (-x)) (rHi : exp (-x) ≤ (c.rHi:ℝ))
    {w : ℕ → ℝ} (unit : ∀ i, w i ∈ Set.Icc (0:ℝ) 1) :
    (∑ i ∈ range 6, |drift w (i+1) x| * (radius x)^(i+2)) ≤ (c.drift:ℝ)*s x := by
  obtain ⟨hx,rhoCap,_,_⟩ := cell_radii hc.1 xa xb
  obtain ⟨m2,m3,m4,m5⟩ := cell_moment_caps hc.1 hx rLo rHi
  have m6 := cell_sixth hc.1 hx rHi
  let ρ := radius x
  have rp : 0 < ρ := radius_pos x
  have term (a : ℕ) (M : ℝ) (hm : |cycleMoment (a+1) x| ≤ M) :
      |drift w a x| * ρ^(a+1) * ρ ≤ M*(c.rho:ℝ)^(a+2)/a.factorial := by
    have f : (0:ℝ) < a.factorial := by positivity
    have diff : |w (a+1)-w a| ≤ 1 := abs_le.mpr
      ⟨by linarith [(unit (a+1)).1,(unit a).2],by linarith [(unit (a+1)).2,(unit a).1]⟩
    have cap : |w (a+1)-w a| * |cycleMoment (a+1) x| ≤ M :=
      (mul_le_of_le_one_left (abs_nonneg _) diff).trans hm
    have prod := mul_le_mul cap (pow_le_pow_left₀ rp.le rhoCap (a+2))
      (pow_nonneg rp.le _) ((abs_nonneg _).trans hm)
    rw [drift,abs_div,abs_mul,abs_of_pos f,div_mul_eq_mul_div,div_mul_eq_mul_div,
      mul_assoc (_*_) _ _,←pow_succ]
    exact div_le_div_of_nonneg_right prod f.le
  have d2 := term 1 _ m2
  have d3 := term 2 _ m3
  have d4 := term 3 _ m4
  have d5 := term 4 _ m5
  have d6 := term 5 _ m6
  have m7 := cell_seventh (c:=c) hx rHi
  have d7 := term 6 _ m7
  norm_num [Nat.factorial] at d2 d3 d4 d5 d6 d7
  have PL : (0:ℝ) < (piLo:ℝ) := by norm_num [piLo,LongCycleFinite.K5CompactCert.piLo]
  have raw := hc.2.2.2.1
  change c.computedDrift ≤ c.drift at raw
  have cast : ((c.m2:ℝ)*c.rho^3+(c.m3:ℝ)*c.rho^4/2+(c.m4:ℝ)*c.rho^5/6+
      (c.m5:ℝ)*c.rho^6/24+(c.m6:ℝ)*c.rho^7/120+(c.m7:ℝ)*c.rho^8/720)/(piLo:ℝ) ≤ (c.drift:ℝ) := by exact_mod_cast raw
  have dnon : 0 ≤ (c.drift:ℝ) := by
    apply le_trans _ cast
    apply div_nonneg _ PL.le
    have h2 := (abs_nonneg _).trans m2
    have h3 := (abs_nonneg _).trans m3
    have h4 := (abs_nonneg _).trans m4
    have h5 := (abs_nonneg _).trans m5
    have h6 := (abs_nonneg _).trans m6
    have h7 := (abs_nonneg _).trans m7
    have hρ := rp.le.trans rhoCap
    positivity
  rw [s,← mul_div_assoc]
  apply (le_div_iff₀ rp).mpr
  simp only [sum_range_succ, sum_range_zero, zero_add, Nat.reduceAdd, add_mul]
  apply le_trans _ (mul_le_mul_of_nonneg_left pi_enclosure.1 dnon)
  linarith only [d2,d3,d4,d5,d6,d7,(div_le_iff₀ PL).mp cast]

theorem cell_tilt_caps {c : Cell} (hc : c.Valid) {x : ℝ} (xa : (c.a:ℝ) ≤ x)
    (xb : x ≤ (c.b:ℝ)) {w : ℕ → ℝ} (w1 : w 1 = 0) (unit : ∀ i, w i ∈ Set.Icc (0:ℝ) 1) :
    |tiltCoefficient w 1 x| ≤ (c.b1:ℝ) ∧ |tiltCoefficient w 2 x| ≤ (c.b2:ℝ) ∧
    |tiltCoefficient w 3 x| ≤ (c.b3:ℝ) ∧ |tiltCoefficient w 4 x| ≤ (c.b4:ℝ) ∧
    |tiltCoefficient w 5 x| ≤ (c.b5:ℝ) ∧ |tiltCoefficient w 6 x| ≤ (c.b6:ℝ) := by
  obtain ⟨hx,_,_,_⟩ := cell_radii hc.1 xa xb
  obtain ⟨rLo,rHi⟩ := Cell.r_bounds hc xa xb
  obtain ⟨m2,m3,m4,m5⟩ := cell_moment_caps hc.1 hx rLo rHi
  let r := exp (-x)
  have rp : 0 < r := exp_pos _
  have hp : 0 < (c.rHi:ℝ) := rp.trans_le rHi
  have h1 : r/(1+r) ≤ (c.rHi:ℝ)/(1+c.rHi) := by
    rw [div_le_div_iff₀ (by positivity) (by positivity)]
    linarith
  have coef (a : ℕ) (M : ℝ) (hm : |cycleMoment a x| ≤ M) :
      |tiltCoefficient w a x| ≤ M / a.factorial := by
    have diff : |w a-1| ≤ 1 := abs_le.mpr ⟨by linarith [(unit a).1],by linarith [(unit a).2]⟩
    rw [tiltCoefficient,abs_div,abs_mul,abs_of_pos (by positivity : (0:ℝ)<a.factorial)]
    exact div_le_div_of_nonneg_right ((mul_le_of_le_one_left (abs_nonneg _) diff).trans hm) (by positivity)
  have a2 := coef 2 _ m2
  have a3 := coef 3 _ m3
  have a4 := coef 4 _ m4
  have a5 := coef 5 _ m5
  have a6 := coef 6 _ (cell_sixth hc.1 hx rHi)
  norm_num [Nat.factorial] at a2 a3 a4 a5 a6
  refine ⟨?_,a2.trans (by exact_mod_cast roundUp_ge (c.m2/2)),
    a3.trans (by exact_mod_cast roundUp_ge (c.m3/6)),a4.trans (by exact_mod_cast roundUp_ge (c.m4/24)),
    a5.trans (by exact_mod_cast roundUp_ge (c.m5/120)),by simpa [Cell.b6] using a6⟩
  have eq : tiltCoefficient w 1 x = r/(1+r) := (FixedFour.tilt_forms w w1 x).1
  rw [eq,abs_of_pos (by positivity)]
  exact h1.trans (by exact_mod_cast roundUp_ge (c.rHi/(1+c.rHi)))

theorem cost_on_radius {c : Cell} (hc : c.Valid) {x R T : ℝ}
    (xa : (c.a:ℝ) ≤ x) (xb : x ≤ (c.b:ℝ)) {w : ℕ → ℝ}
    (w1 : w 1=0) (unit : ∀ i, w i ∈ Set.Icc (0:ℝ) 1) (rp : 0≤R) (rt : R≤T) :
    cost (fun a ↦ tiltCoefficient w a x) R 6 ≤
      (c.b1:ℝ)*T+c.b2*T^2+c.b3*T^3+c.b4*T^4+c.b5*T^5+c.b6*T^6 := by
  obtain ⟨a1,a2,a3,a4,a5,a6⟩ := cell_tilt_caps hc xa xb w1 unit
  have term (i : ℕ) (M : ℝ) (h : |tiltCoefficient w i x| ≤ M) :
      |tiltCoefficient w i x| * R^i ≤ M*T^i :=
    mul_le_mul h (pow_le_pow_left₀ rp rt _) (pow_nonneg rp _) ((abs_nonneg _).trans h)
  simpa only [cost,sum_range_succ,sum_range_zero,zero_add,Nat.reduceAdd,pow_one] using
    add_le_add (add_le_add (add_le_add (add_le_add (add_le_add
      (term 1 _ a1) (term 2 _ a2)) (term 3 _ a3)) (term 4 _ a4)) (term 5 _ a5)) (term 6 _ a6)

theorem cell_cost {c : Cell} (hc : c.Valid) {x : ℝ} (xa : (c.a:ℝ) ≤ x)
    (xb : x ≤ (c.b:ℝ)) {w : ℕ → ℝ} (w1 : w 1=0) (unit : ∀ i, w i ∈ Set.Icc (0:ℝ) 1) :
    cost (fun a ↦ tiltCoefficient w a x) ((c.lambda:ℝ)*radius x) 6 ≤ (c.cost:ℝ) := by
  obtain ⟨_,hρ,_,_⟩ := cell_radii hc.1 xa xb
  have l1 : (1:ℝ) < c.lambda := by exact_mod_cast hc.1.2.2.2.2.2.2.2.2.1
  have l0 : (0:ℝ) ≤ c.lambda := by linarith
  have rr : (c.lambda:ℝ)*radius x ≤ (c.radius:ℝ) := by
    simpa [Cell.radius,mul_comm] using mul_le_mul_of_nonneg_left hρ l0
  have h := cost_on_radius hc xa xb w1 unit (mul_nonneg l0 (radius_pos x).le) rr
  apply h.trans
  exact_mod_cast (show c.computedCost ≤ c.cost from hc.2.1.2.2.2.2.2.2.2.2.1)

theorem cell_inverse_amplitude {c : Cell} (hc : c.Valid) {x : ℝ} (xa : (c.a:ℝ) ≤ x)
    (xb : x ≤ (c.b:ℝ)) {w : ℕ → ℝ} (w1 : w 1=0) (unit : ∀ i, w i ∈ Set.Icc (0:ℝ) 1) :
    1 ≤ ‖tiltValue (fun a ↦ tiltCoefficient w a x) 6 (nearestPole x)‖ * (c.invD:ℝ) := by
  let b := fun a ↦ tiltCoefficient w a x
  have hρ := (cell_radii hc.1 xa xb).2.1
  have h := cost_on_radius hc xa xb w1 unit (radius_pos x).le hρ
  have hcost : cost b (radius x) 6 ≤ (c.loss:ℝ) := h.trans
    (by exact_mod_cast (show c.computedLoss ≤ c.loss from hc.2.1.2.2.2.2.1))
  have lo := (tilt_value_bounds b 6 (nearestPole x) (nearestPole_norm x).le).1
  have hi := (exp_le_exp.mpr hcost).trans (Cell.exponent_bounds hc).2
  have t := mul_le_mul lo hi (exp_pos _).le (norm_nonneg _)
  rwa [← exp_add,neg_add_cancel,exp_zero] at t

#print axioms cell_drift
#print axioms cell_inverse_amplitude
end LongCycleBounds.SevenCutoff
