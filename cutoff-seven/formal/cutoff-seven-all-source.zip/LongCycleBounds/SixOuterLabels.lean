import LongCycleBounds.SixOuterScalars
import LongCycleBounds.FixedCutoffLabels

/-! Exterior mass estimates for a signed quintic tilt. -/
noncomputable section
namespace LongCycleBounds.SixCutoff.Exterior
open Real Finset FixedCutoff MarkedTwo PowerSeries

def poly (R : ℝ) := R+R^2/2+R^3/6+R^4/24+R^5/120

theorem poly_mono {R N : ℝ} (hR : 0≤R) (h : R≤N) : poly R ≤ poly N := by
  dsimp [poly]
  linarith only [h,pow_le_pow_left₀ hR h 2,pow_le_pow_left₀ hR h 3,
    pow_le_pow_left₀ hR h 4,pow_le_pow_left₀ hR h 5]

theorem poly_bound {N : ℝ} (hn : 49≤N) : poly N ≤ N^5/100 := by
  have nn : 0≤N := by linarith
  have h1 := mul_le_mul_of_nonneg_right hn nn
  have h2 := mul_le_mul_of_nonneg_right hn (sq_nonneg N)
  have h3 := mul_le_mul_of_nonneg_right hn (pow_nonneg nn 3)
  have h4 := mul_le_mul_of_nonneg_right hn (pow_nonneg nn 4)
  dsimp [poly]
  nlinarith only [h1,h2,h3,h4]

theorem physical_poly_cost {n : ℕ} (hn : 49≤n) {x : ℝ}
    (outer : 3*sqrt ((n-1:ℕ):ℝ)≤x) : exp (-x)*poly n*(6*(n:ℝ)+1)≤1 := by
  have r := sixth_power hn outer
  have N : (49:ℝ)≤n := by exact_mod_cast hn
  have non : 0≤poly (n:ℝ) := by dsimp [poly]; positivity
  have A := mul_le_mul_of_nonneg_left (poly_bound N) (exp_pos (-x)).le
  have p := mul_le_mul_of_nonneg_right A (show 0≤6*(n:ℝ)+1 by positivity)
  nlinarith only [p,r,
    mul_nonneg (mul_nonneg (exp_pos (-x)).le (pow_nonneg (Nat.cast_nonneg n) 5))
      (show 0≤(n:ℝ)-1 by linarith)]

theorem positive_label {n j d : ℕ} (hn : 49≤n) (hj : 1≤j) (hjn : j≤n)
    {x h : ℝ} (hh : 1≤h) (outer : 3*sqrt ((n-1:ℕ):ℝ)≤x)
    (b : ℕ→ℝ) (cost_bound : ∀ R, 0≤R → cost b R d≤exp (-x)*poly R) :
    |label b d h j-h^j| ≤ h^j/(6*(n:ℝ)) := by
  let R : ℝ := j/h
  have hpos : 0<h := by linarith
  have R0 : 0≤R := div_nonneg (Nat.cast_nonneg _) hpos.le
  have RN : R≤n := (div_le_iff₀ hpos).mpr <|
    (show (j:ℝ)≤n by exact_mod_cast hjn).trans (le_mul_of_one_le_right (Nat.cast_nonneg _) hh)
  have cap := (cost_bound R R0).trans
    (mul_le_mul_of_nonneg_left (poly_mono R0 RN) (exp_pos _).le)
  have hN : (49:ℝ)≤n := by exact_mod_cast hn
  have cp := (mul_le_mul_of_nonneg_right cap (show 0≤6*(n:ℝ)+1 by positivity)).trans
    (physical_poly_cost hn outer)
  have v0 : 0≤cost b R d := sum_nonneg fun i _ ↦ mul_nonneg (abs_nonneg _) (by positivity)
  have small : cost b R d < 1 := by
    nlinarith only [cp,mul_nonneg (show 0≤6*(n:ℝ)-1 by linarith) v0]
  have rel : exp (cost b R d)-1 ≤ 1/(6*(n:ℝ)) := by
    apply (sub_le_sub_right (exp_bound_div_one_sub_of_interval v0 small) 1).trans
    rw [sub_le_iff_le_add,div_le_iff₀ (sub_pos.mpr small)]
    have np : 0<6*(n:ℝ) := by positivity
    apply le_of_mul_le_mul_left (a:=6*(n:ℝ)) _ np
    field_simp [np.ne']
    nlinarith only [cp]
  apply (positive_label_error b d hpos hj).trans
  simpa [R,div_eq_mul_inv] using mul_le_mul_of_nonneg_left rel (pow_nonneg hpos.le j)

/-- The nonconstant coefficient uses exp(cost)-1. This removes the artificial
growth of the test radius when x goes to infinity. -/
theorem zero_label_nonconstant (b : ℕ→ℝ) (d : ℕ) {R : ℝ} (hr : 0<R)
    {j : ℕ} (hj : 0<j) :
    |label b d 0 j| ≤ j.factorial*(exp (cost b R d)-1)/R^j := by
  have form (i : ℕ) : scaledCoeff (linearExp 0) R i = if i=0 then R else 0 := by
    by_cases hi : i=0 <;> simp [scaledCoeff,linearExp,coeff_mk,hi]
  have bd (i : ℕ) : |scaledCoeff (linearExp 0) R i| ≤ R := by
    rw [form]; split <;> simp [abs_of_pos hr,hr.le]
  have u := signed_tilt_bias b hr.le hr.le (linearExp 0) d j (fun i _ ↦ bd i)
  rw [form,if_neg (Nat.ne_of_gt hj),sub_zero] at u
  dsimp only [scaledCoeff] at u
  rw [abs_mul,abs_of_pos (pow_pos hr _),pow_succ] at u
  have c : R^j*|coeff j (tilt b d*linearExp 0)| ≤ exp (cost b R d)-1 :=
    le_of_mul_le_mul_left (a:=R) (by nlinarith only [u]) hr
  rw [label,abs_mul,abs_of_nonneg (by positivity : 0≤(j.factorial:ℝ)),le_div_iff₀ (pow_pos hr j)]
  nlinarith only [mul_le_mul_of_nonneg_left c (by positivity : (0:ℝ)≤j.factorial)]

theorem zero_label {n j d : ℕ} (hn : 49≤n) (hj : n-6≤j) (hjn : j≤n) {x : ℝ}
    (outer : 3*sqrt ((n-1:ℕ):ℝ) ≤ x) (b : ℕ→ℝ)
    (cb : ∀ R, 0≤R → cost b R d ≤ exp (-x)*poly R) :
    |label b d 0 j| ≤ exp (-x)/(6*(n:ℝ)) := by
  let N : ℝ := n
  let R := 2*N
  have N49 : 49≤N := by dsimp [N]; exact_mod_cast hn
  have np : 0<N := by linarith
  have rp : 0<R := by dsimp [R]; positivity
  have R49 : 49≤R := by dsimp [R]; linarith
  have pre := (cb R rp.le).trans (mul_le_mul_of_nonneg_left (poly_bound R49) (exp_pos _).le)
  have bud := sixth_power hn outer
  have bud' : (1/14:ℝ)*(exp (-x)*N^6)<1 := bud
  have rc : cost b R d ≤ (32/100:ℝ)*exp (-x)*N^5 := by
    dsimp only [R] at pre
    nlinarith only [pre]
  have cov := mul_le_mul_of_nonneg_right rc np.le
  have small : cost b R d ≤ 1/2 := by
    by_contra! bad
    nlinarith only [cov,bud',mul_lt_mul_of_pos_right bad np,N49]
  have v0 : 0≤cost b R d := sum_nonneg fun i _ ↦ mul_nonneg (abs_nonneg _) (pow_nonneg rp.le _)
  have ex := exp_bound_div_one_sub_of_interval v0 (small.trans_lt (by norm_num))
  have near : exp (cost b R d)-1 ≤ 2*cost b R d := by
    apply (sub_le_sub_right ex 1).trans
    rw [sub_le_iff_le_add,div_le_iff₀ (by linarith : 0<1-cost b R d)]
    nlinarith only [mul_nonneg v0 (show 0≤1-2*cost b R d by linarith)]
  have expcap : exp (cost b R d)-1 ≤ exp (-x)*N^5 := by
    linarith only [near,rc,mul_nonneg (exp_pos (-x)).le (pow_nonneg np.le 5)]
  have fj : (j.factorial:ℝ) ≤ N^j := by
    dsimp [N]
    exact_mod_cast j.factorial_le_pow.trans (Nat.pow_le_pow_left hjn j)
  have nj : N^j ≥ 0 := pow_nonneg np.le _
  have power : 6*N^6 ≤ (2:ℝ)^j :=
    (le_trans (by nlinarith only [pow_nonneg np.le 6]) (reserve hn)).trans
      (pow_le_pow_right₀ (by norm_num) hj)
  apply (zero_label_nonconstant b d rp (by omega : 0<j)).trans
  rw [div_le_div_iff₀ (pow_pos rp _) (show 0<6*(n:ℝ) by dsimp only [N] at np; positivity)]
  have big := mul_le_mul fj expcap (by linarith [exp_le_exp.mpr v0,exp_zero] :
    0≤exp (cost b R d)-1) nj
  change _ ≤ exp (-x)*R^j
  dsimp only [R]
  rw [mul_pow]
  change (j.factorial:ℝ)*(exp (cost b (2*N) d)-1)*(6*N)≤_
  change (j.factorial:ℝ)*(exp (cost b (2*N) d)-1)≤_ at big
  nlinarith only [mul_le_mul_of_nonneg_right big (show 0≤6*N by positivity),
    mul_le_mul_of_nonneg_right power (mul_nonneg (exp_pos (-x)).le nj)]

#print axioms physical_poly_cost
#print axioms positive_label
#print axioms zero_label_nonconstant
#print axioms zero_label
end LongCycleBounds.SixCutoff.Exterior
