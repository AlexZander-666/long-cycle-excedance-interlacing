import LongCycleBounds.OuterDecayEnvelope
import LongCycleFinite.K5CompactCert.ExpBounds
import Mathlib.Analysis.Real.Pi.Bounds

/-! Explicit real bounds for each part of the middle convolution. -/
namespace LongCycleBounds.SevenCutoff.Middle

open Real LongCycleFinite.K5CompactCert

theorem exp_neg_sixteen : exp (-16) ≤ (1/8800000:ℝ) := by
  have h : (8800000:ℚ) ≤ expTaylor 16 64 := by decide +kernel
  have real : (8800000:ℝ) ≤ (expTaylor 16 64:ℝ) := by exact_mod_cast h
  have tay := expTaylor_le_exp (q := 16) (by decide) 64
  have large : (8800000:ℝ) ≤ exp 16 := real.trans (by simpa using tay)
  rw [exp_neg, ← one_div]
  apply (div_le_iff₀ (exp_pos _)).mpr
  linarith only [large]

/-- The certified upper radius ratio applies on the whole half-line x ≥ 16. -/
theorem radius_le_alpha {x : ℝ} (hx : 16 ≤ x) :
    sqrt (x ^ 2 + π ^ 2) ≤ (51/50 : ℝ) * x := by
  have hpi : π ≤ (22/7 : ℝ) := by linarith [pi_lt_d6]
  have halpha : 0 < (51/50 : ℝ) := by norm_num
  have ha : 1 + ((22/7 : ℝ) / 16) ^ 2 ≤ (51/50 : ℝ) ^ 2 := by
    norm_num
  have hx0 : 0 ≤ x := by linarith
  have hpi2 : π ^ 2 ≤ ((22/7 : ℝ) / 16) ^ 2 * x ^ 2 := by
    calc
      π ^ 2 ≤ (22/7 : ℝ) ^ 2 := pow_le_pow_left₀ pi_pos.le hpi 2
      _ = ((22/7 : ℝ) / 16) ^ 2 * 16 ^ 2 := by ring
      _ ≤ _ := mul_le_mul_of_nonneg_left (pow_le_pow_left₀ (by norm_num) hx 2) (sq_nonneg _)
  apply (sq_le_sq₀ (sqrt_nonneg _) (mul_nonneg halpha.le hx0)).mp
  rw [sq_sqrt (by positivity)]
  calc
    x ^ 2 + π ^ 2 ≤ (1 + ((22/7 : ℝ) / 16) ^ 2) * x ^ 2 := by linarith only [hpi2]
    _ ≤ ((51/50 : ℝ) * x) ^ 2 := by
      rw [mul_pow]
      exact mul_le_mul_of_nonneg_right ha (sq_nonneg x)

/-- Every power needed in the middle region is controlled by the endpoint at 16. -/
theorem x_power_decay {x : ℝ} (hx : 16 ≤ x) {m : ℕ} (hm : m ≤ 9) :
    exp (-x) * x ^ m ≤ 16 ^ m * (1/8800000 : ℝ) := by
  let d := (x - 16) / 9
  have hd : 0 ≤ d := by dsimp [d]; linarith
  have hx0 : 0 ≤ x := by linarith
  have hxexp : x ≤ 16 * exp d := by
    have h := add_one_le_exp d
    dsimp [d] at h
    linarith
  have hpow := pow_le_pow_left₀ hx0 hxexp m
  rw [mul_pow, ← exp_nat_mul] at hpow
  have hm' : (m : ℝ) ≤ 9 := by exact_mod_cast hm
  have hexp : exp (-x) * exp ((m : ℝ) * d) ≤ exp (-16) := by
    rw [← exp_add]
    apply exp_le_exp.mpr
    have h := mul_le_mul_of_nonneg_right hm' hd
    dsimp [d] at h
    dsimp [d]
    linarith only [h]
  calc
    exp (-x) * x ^ m ≤ exp (-x) * (16 ^ m * exp ((m : ℝ) * d)) :=
      mul_le_mul_of_nonneg_left hpow (exp_nonneg _)
    _ = 16 ^ m * (exp (-x) * exp ((m : ℝ) * d)) := by ring
    _ ≤ _ := mul_le_mul_of_nonneg_left (hexp.trans exp_neg_sixteen) (by positivity)

/-- The same decay estimate with any radius bounded by the certified ratio. -/
theorem radius_power_decay {x R : ℝ} (hx : 16 ≤ x) (hR0 : 0 ≤ R)
    (hR : R ≤ (51/50 : ℝ) * x) {m : ℕ} (hm : m ≤ 9) :
    exp (-x) * R ^ m ≤ (51/50 : ℝ) ^ m * 16 ^ m * (1/8800000 : ℝ) := by
  calc
    exp (-x) * R ^ m ≤ exp (-x) * ((51/50 : ℝ) * x) ^ m :=
      mul_le_mul_of_nonneg_left (pow_le_pow_left₀ hR0 hR m) (exp_nonneg _)
    _ = (51/50 : ℝ) ^ m * (exp (-x) * x ^ m) := by rw [mul_pow]; ring
    _ ≤ _ := by
      rw [mul_assoc]
      exact mul_le_mul_of_nonneg_left (x_power_decay hx hm)
        (pow_nonneg (by norm_num : (0:ℝ) < 51/50).le _)

/-- A geometric bound for the accelerated tilt in the head. -/
theorem exp_sub_one_le {v : ℝ} (hv : 0 ≤ v) (hle : v ≤ (1/200 : ℝ)) :
    exp v - 1 ≤ v / (1 - (1/200 : ℝ)) := by
  have hv0 : (1/200 : ℝ) < 1 := by norm_num
  have hv1 := hle.trans_lt hv0
  have h := exp_bound_div_one_sub_of_interval hv hv1
  have id : 1 / (1 - v) - 1 = v / (1 - v) := by
    field_simp [ne_of_gt (sub_pos.mpr hv1)]
    ring
  calc
    exp v - 1 ≤ 1 / (1 - v) - 1 := sub_le_sub_right h 1
    _ = v / (1 - v) := id
    _ ≤ _ := div_le_div_of_nonneg_left hv (sub_pos.mpr hv0) (sub_le_sub_left hle 1)

theorem cubic_factor : 18*(51/50:ℝ)^3/π < 7 := by
  apply (div_lt_iff₀ pi_pos).mpr
  linarith only [pi_gt_d6]

/-- The scalar multiplying the doubled-radius tail on the specified middle interval. -/
theorem tail_prefactor {p : ℕ} (hp : 95 ≤ p) {x R : ℝ} (hx : 16 ≤ x)
    (hxupper : x ≤ 3 * sqrt (p : ℝ)) (hR0 : 0 ≤ R) (hR : R ≤ (51/50 : ℝ) * x) :
    2 * R ^ 3 / (π * x) < 7 * ((p + 1 : ℕ) : ℝ) := by
  have xp : 0 < x := by linarith
  have pp : 0 < (p : ℝ) := by exact_mod_cast (show 0 < p by omega)
  have hs : x ^ 2 ≤ 9 * (p : ℝ) := by
    calc
      x ^ 2 ≤ (3 * sqrt (p : ℝ)) ^ 2 := pow_le_pow_left₀ xp.le hxupper 2
      _ = _ := by rw [mul_pow, sq_sqrt pp.le]; norm_num
  calc
    2 * R ^ 3 / (π * x) ≤ 2 * ((51/50 : ℝ) * x) ^ 3 / (π * x) :=
      div_le_div_of_nonneg_right
        (mul_le_mul_of_nonneg_left (pow_le_pow_left₀ hR0 hR 3) (by norm_num)) (by positivity)
    _ = (18 * (51/50 : ℝ) ^ 3 / π) * (x ^ 2 / 9) := by
      field_simp [xp.ne', pi_pos.ne']
      ring
    _ ≤ (18 * (51/50 : ℝ) ^ 3 / π) * (p : ℝ) := by
      have ha : 0 ≤ (51/50 : ℝ) := (by norm_num)
      exact mul_le_mul_of_nonneg_left ((div_le_iff₀ (by norm_num)).mpr
        (by linarith only [hs])) (by positivity)
    _ < 7 * (p : ℝ) := mul_lt_mul_of_pos_right cubic_factor pp
    _ ≤ _ := by push_cast; linarith

theorem head_prefactor {n : ℕ} (hn : 96 ≤ n) {x R v : ℝ} (hx : 16 ≤ x) (hRp : 0 < R)
    (hR : R ≤ (51/50 : ℝ) * x) (hv : 0 ≤ v) (hcost : v ≤ (100117/47185920 : ℝ) * exp (-x) * R ^ 6)
    (hsmall : v ≤ (1/200 : ℝ)) :
    (2 + 2 * R ^ 2 / (((n - 5 : ℕ) : ℝ) * π ^ 2)) * (exp v - 1) ≤
      (1/16 : ℝ) * (π / R) := by
  let P : ℝ := 157/50
  let D : ℝ := 91 * P ^ 2
  let U : ℝ := 1 - (1/200 : ℝ)
  have hp : 0 < P := by norm_num [P]
  have hP : P ≤ π := by
    norm_num [P]
    linarith [pi_gt_d6]
  have hd : 0 < D := by dsimp [D]; positivity
  have hu : 0 < U := by norm_num [U]
  have hC : 0 ≤ (100117/47185920 : ℝ) := by norm_num
  have hn' : (91 : ℝ) ≤ ((n - 5 : ℕ) : ℝ) := by exact_mod_cast (show 91 ≤ n - 5 by omega)
  have hD : D ≤ ((n - 5 : ℕ) : ℝ) * π ^ 2 :=
    mul_le_mul hn' (pow_le_pow_left₀ hp.le hP 2) (sq_nonneg _) (by norm_num)
  have hmass : 2 + 2 * R ^ 2 / (((n - 5 : ℕ) : ℝ) * π ^ 2) ≤ 2 + 2 * R ^ 2 / D :=
    add_le_add (le_refl _) (div_le_div_of_nonneg_left (by positivity) hd hD)
  have hv' : exp v - 1 ≤ (100117/47185920 : ℝ) * exp (-x) * R ^ 6 / U :=
    (exp_sub_one_le hv hsmall).trans (div_le_div_of_nonneg_right hcost hu.le)
  have hnonneg : 0 ≤ exp v - 1 := by simpa using exp_le_exp.mpr hv
  have hmass0 : 0 ≤ 2 + 2 * R ^ 2 / D := by positivity
  have h5 := radius_power_decay hx hRp.le hR (m := 7) (by decide)
  have h7 := radius_power_decay hx hRp.le hR (m := 9) (by decide)
  have hsums :
      2 * (exp (-x) * R ^ 7) + 2 * (exp (-x) * R ^ 9) / D ≤
        2 * ((51/50 : ℝ) ^ 7 * 16 ^ 7 * (1/8800000 : ℝ)) +
          2 * ((51/50 : ℝ) ^ 9 * 16 ^ 9 * (1/8800000 : ℝ)) / D :=
    add_le_add (mul_le_mul_of_nonneg_left h5 (by norm_num))
      (div_le_div_of_nonneg_right (mul_le_mul_of_nonneg_left h7 (by norm_num)) hd.le)
  have hhead : 0 ≤ (1/16 : ℝ) := by norm_num
  rw [← mul_div_assoc (1/16 : ℝ) π R]
  apply (le_div_iff₀ hRp).2
  calc
    (2 + 2 * R ^ 2 / (((n - 5 : ℕ) : ℝ) * π ^ 2)) * (exp v - 1) * R ≤
        (2 + 2 * R ^ 2 / D) * ((100117/47185920 : ℝ) * exp (-x) * R ^ 6 / U) * R :=
      mul_le_mul_of_nonneg_right (mul_le_mul hmass hv' hnonneg hmass0) hRp.le
    _ = (100117/47185920 : ℝ) * (2 * (exp (-x) * R ^ 7) + 2 * (exp (-x) * R ^ 9) / D) / U := by ring
    _ ≤ (100117/47185920 : ℝ) * (2 * ((51/50 : ℝ) ^ 7 * 16 ^ 7 * (1/8800000 : ℝ)) +
        2 * ((51/50 : ℝ) ^ 9 * 16 ^ 9 * (1/8800000 : ℝ)) / D) / U :=
      div_le_div_of_nonneg_right (mul_le_mul_of_nonneg_left hsums hC) hu.le
    _ = ((100117/47185920 : ℝ) * (1/8800000 : ℝ) *
        (2 * (51/50 : ℝ) ^ 7 * 16 ^ 7 + 2 * (51/50 : ℝ) ^ 9 * 16 ^ 9 / D) / (P * U)) * P := by
      field_simp [hp.ne', hu.ne', hd.ne']
    _ ≤ (1/16 : ℝ) * P := mul_le_mul_of_nonneg_right (by norm_num [D,P,U]) hp.le
    _ ≤ (1/16 : ℝ) * π := mul_le_mul_of_nonneg_left hP hhead

private theorem tail_nat (m : ℕ) (hm : 44 ≤ m) : 14000*(2*m+8) ≤ 2^m := by
  induction m, hm using Nat.le_induction with
  | base => decide
  | succ m hm ih =>
    rw [pow_succ]
    omega

theorem tail_bound {n j : ℕ} (hn : 96 ≤ n) (hj : n-7 ≤ j) :
    14*(n:ℝ)/2^(j/2) ≤ 1/1000 := by
  have h := tail_nat (j/2) (by omega)
  have hn' : 14000*n ≤ 2^(j/2) := by omega
  have hr : 14000*(n:ℝ) ≤ 2^(j/2) := by exact_mod_cast hn'
  apply (div_le_iff₀ (by positivity)).mpr
  linarith only [hr]

theorem bare_mass_reserve {n : ℕ} (hn : 96 ≤ n) :
    2+(n:ℝ)/((n-6:ℕ):ℝ)+1/4 < 4 := by
  have hn' : (96:ℝ) ≤ n := by exact_mod_cast hn
  have hd : ((n-6:ℕ):ℝ) = (n:ℝ)-6 := by
    rw [Nat.cast_sub (by omega : 6≤n)]
    norm_num
  rw [hd]
  have hratio : (n:ℝ)/((n:ℝ)-6) ≤ 96/90 := by
    apply (div_le_iff₀ (by linarith)).mpr
    linarith
  linarith

#print axioms exp_neg_sixteen
#print axioms radius_power_decay
#print axioms tail_prefactor
#print axioms head_prefactor
#print axioms tail_bound
end LongCycleBounds.SevenCutoff.Middle
