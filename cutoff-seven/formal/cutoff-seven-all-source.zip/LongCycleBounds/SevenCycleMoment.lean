import LongCycleBounds.SixCutoffMoments
import LongCycleBounds.SevenMomentBounds

/-! The true seventh insertion moment and the failure of the previous constants. -/
noncomputable section
namespace LongCycleBounds.SevenCutoff
open Real Band FiveCutoff

private theorem height_diff (x : ℝ) :
    HasDerivAt (fun y : ℝ ↦ height (exp (-y)))
      (-height (exp (-x))*imbalance (exp (-x))) x := by
  have r : HasDerivAt (fun y : ℝ ↦ exp (-y)) (-exp (-x)) x := by
    simpa using (hasDerivAt_id x).neg.exp
  have den := (r.const_add 1).pow 2
  have nz : 1+exp (-x)≠0 := by positivity
  have d := r.div den (show (1+exp (-x))^2≠0 from pow_ne_zero _ nz)
  apply d.congr_deriv
  simp only [height,imbalance,Pi.pow_apply,Nat.cast_ofNat,Nat.reduceSub,pow_one]
  field_simp
  ring

theorem seventh_moment (x : ℝ) :
    let r := exp (-x)
    cycleMoment 7 x = -r*numerator r/(1+r)^7 := by
  let G := fun y : ℝ ↦ height (exp (-y))
  have gr := height_diff x
  have form : cycleMoment 6 = fun y ↦ -(G y)*(1-30*G y+120*(G y)^2) := by
    funext y; exact SixCutoff.sixth_moment y
  have at6 := cycleMoment_hasDerivAt (a:=6) (by decide) x
  rw [form] at at6
  have calcD := gr.neg.mul (((gr.const_mul 30).const_sub 1).add ((gr.pow 2).const_mul 120))
  have eqn := at6.unique calcD
  simp only [Nat.reduceAdd] at eqn
  dsimp [G,height,imbalance,numerator] at eqn ⊢
  have den : 1+exp (-x)≠0 := by positivity
  field_simp at eqn ⊢
  linear_combination -eqn

theorem seventh_envelopes {x : ℝ} (hx : 0≤x) :
    |cycleMoment 7 x| ≤ 11/6 * height (exp (-x)) ∧
    |cycleMoment 7 x| ≤ 21/20 * exp (-x) := by
  let r := exp (-x)
  have rp : 0<r := exp_pos _
  have r1 : r≤1 := exp_le_one_iff.mpr (by linarith)
  have dn : 0<1+r := by linarith
  rw [seventh_moment]
  change |(-r)*numerator r/(1+r)^7| ≤ 11/6*height r ∧
    |(-r)*numerator r/(1+r)^7| ≤ 21/20*r
  rw [abs_div,abs_mul,abs_neg,abs_of_pos rp,abs_of_pos (pow_pos dn 7)]
  have hbd : |numerator r|≤11/6*(1+r)^5 := abs_le.mpr
    ⟨by linarith only [height_plus r rp.le r1],by linarith only [height_minus r rp.le r1]⟩
  have rbd : |numerator r|≤21/20*(1+r)^7 := abs_le.mpr
    ⟨by linarith only [radius_plus r rp.le r1],by linarith only [radius_minus r rp.le r1]⟩
  constructor
  · apply (div_le_iff₀ (pow_pos dn 7)).mpr
    exact (mul_le_mul_of_nonneg_left hbd rp.le).trans_eq (by unfold height; field_simp)
  · apply (div_le_iff₀ (pow_pos dn 7)).mpr
    exact (mul_le_mul_of_nonneg_left rbd rp.le).trans_eq (by ring)

theorem seventh_at_log_eleven :
    |cycleMoment 7 (log 11)| = (258335/248832)*exp (-(log 11)) := by
  rw [seventh_moment,exp_neg,exp_log (by norm_num : (0:ℝ)<11)]
  norm_num [numerator]

theorem seventh_at_log_two :
    |cycleMoment 7 (log 2)| = (49/27)*height (exp (-(log 2))) := by
  rw [seventh_moment,exp_neg,exp_log (by norm_num : (0:ℝ)<2)]
  norm_num [numerator,height]

#print axioms seventh_moment
#print axioms seventh_envelopes
#print axioms seventh_at_log_eleven
#print axioms seventh_at_log_two
end LongCycleBounds.SevenCutoff
