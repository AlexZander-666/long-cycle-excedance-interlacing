import LongCycleBounds.SevenCompactVerified
import LongCycleBounds.SevenMiddle
import LongCycleBounds.SevenExterior
import LongCycleBounds.CycleProfileIndependentReadout

/-! Minimum cycle length seven for upper sizes at least 96, with independent weights from size 96. -/
namespace LongCycleBounds.SevenCutoff
open Real LongCycles LongCycleFinite FixedCutoff PoleBridge CycleProfile

theorem normalized_sign {p : ℕ} (hp : 95 ≤ p) (w : ℕ → ℝ)
    (one : w 1 = 0) (unit : ∀ a, w a ∈ Set.Icc (0:ℝ) 1) (tail : ∀ a ≥ 7, w a = 1)
    {x : ℝ} (hx : 0 ≤ x) (zero : normalizedRow w p x = 0) :
    0 < normalizedRow w (p+1) x * (-deriv (normalizedRow w p) x) := by
  by_cases compact : x ≤ 16
  · exact compact_sign one tail unit hx compact hp zero
  by_cases inside : x ≤ 3*sqrt (p:ℝ)
  · exact middle_sign one tail unit (le_of_not_ge compact) hp inside zero
  exact exterior_sign (by omega) w one tail unit (le_of_not_ge inside) zero

/-- From upper size 96, every choice of independent short-cycle weights in
the closed cube yields strict quotient and weak original interlacing. -/
theorem independent_weights {n : ℕ} (hn : 96 ≤ n)
    (w : ℕ → ℝ) (one : w 1 = 0) (unit : ∀ a, w a ∈ Set.Icc (0 : ℝ) 1)
    (tail : ∀ a ≥ 7, w a = 1) :
    StrictNegativeInterlacing (weightedQuotient (n-1) w) (weightedQuotient n w) (n-3) ∧
      WeakRealInterlacing (row (n-1) w) (row n w) := by
  apply independent_interlacing_of_normalized_sign (by decide : 3 ≤ 7) (by omega)
    (w := w) <;> try assumption
  intro v v1 vu vt x hx hz
  simpa only [show n-1+1=n by omega] using normalized_sign (by omega : 95 ≤ n-1) v v1 vu vt hx hz

/-- Setting all five short-cycle weights to zero restores the original
permutation enumerators with minimum cycle length seven. -/
theorem original {n : ℕ} (hn : 96 ≤ n) :
    StrictNegativeInterlacing (Band.generalCycleQuotient (n-1) 7)
        (Band.generalCycleQuotient n 7) (n-3) ∧
      WeakRealInterlacing (enumerator (n-1) 7) (enumerator n 7) := by
  have unit (a : ℕ) : profile 7 0 a ∈ Set.Icc (0:ℝ) 1 := by
    by_cases h : a<7 <;> simp [profile,h]
  have tail (a : ℕ) (ha : 7 ≤ a) : profile 7 0 a = 1 := by simp [profile,not_lt.mpr ha]
  simpa only [(weightedQuotient_endpoints (by decide : 2 ≤ 7) (by omega : 0<n-1)).1,
    (weightedQuotient_endpoints (by decide : 2 ≤ 7) (by omega : 0<n)).1,
    row_zero _ (by decide : 2 ≤ 7)] using independent_weights hn (profile 7 0) (by rfl) unit tail


#print axioms normalized_sign
#print axioms independent_weights
#print axioms original
end LongCycleBounds.SevenCutoff
