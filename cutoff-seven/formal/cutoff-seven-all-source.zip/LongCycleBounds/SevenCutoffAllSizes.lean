import LongCycleBounds.SevenCutoffVerified
import LongCycleFinite.K7Prefix.All

/-! All nondegenerate pairs in the unweighted minimum-cycle-length-seven problem. -/
namespace LongCycleBounds.SevenCutoff

open LongCycleFinite

/-- Every consecutive nonzero hard-cutoff-seven pair has strict quotient
interlacing and weak original interlacing. -/
theorem all_sizes {n : ℕ} (hn : 8 ≤ n) : K7Prefix.OriginalPair n := by
  by_cases small : n ≤ 95
  · exact K7Prefix.finite_original hn small
  obtain ⟨strict,weak⟩ := original (show 96 ≤ n by omega)
  exact ⟨⟨_, _, Band.actual_general_cycle_row (by decide : 2 ≤ 7) (by omega),
    Band.actual_general_cycle_row (by decide : 2 ≤ 7) (by omega), strict⟩, weak⟩

#print axioms all_sizes
end LongCycleBounds.SevenCutoff
