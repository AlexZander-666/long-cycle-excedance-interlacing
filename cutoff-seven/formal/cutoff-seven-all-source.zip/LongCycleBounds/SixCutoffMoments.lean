import LongCycleBounds.FiveMiddleProfile

/-! Fifth-degree tilt and sixth insertion moment for actual cycle weights. -/
noncomputable section
namespace LongCycleBounds.SixCutoff
open Real Polynomial LongCycles FixedCutoff Band FiveCutoff

private theorem e5 : eulerian 5 =
    1+C (26:ℝ)*X+C (66:ℝ)*X^2+C (26:ℝ)*X^3+X^4 := by
  have h2 : eulerian 2 = 1+X := by
    rw [show 2=1+1 by decide,longEulerian_succ,longEulerian_one]
    simp
  have h3 : eulerian 3 = 1+C (4:ℝ)*X+X^2 := by
    change eulerian (2+1)=_
    rw [longEulerian_succ,h2]
    simp [C_ofNat]
    ring
  have h4 : eulerian 4 = 1+C (11:ℝ)*X+C (11:ℝ)*X^2+X^3 := by
    change eulerian (3+1)=_
    rw [longEulerian_succ,h3]
    simp [C_ofNat]
    ring
  change eulerian (4+1)=_
  rw [longEulerian_succ,h4]
  simp [C_ofNat]
  ring

theorem sixth_moment (x : ℝ) :
    let h := height (exp (-x))
    cycleMoment 6 x = -h*(1-30*h+120*h^2) := by
  dsimp only
  have nz : 1+exp (-x) ≠ 0 := by positivity
  simp [cycleMoment,moment,height,e5]
  field_simp
  ring

theorem abs_sixth {x : ℝ} (hx : 0 ≤ x) :
    |cycleMoment 6 x| ≤ height (exp (-x)) := by
  obtain ⟨h0,_,h4,_⟩ := shape_bounds (exp_pos (-x)).le (exp_le_one_iff.mpr (by linarith))
  let h := height (exp (-x))
  have shape : |1-30*h+120*h^2| ≤ 1 := by
    change 0 ≤ h at h0
    change h ≤ 1/4 at h4
    rw [abs_le]
    constructor
    · nlinarith only [sq_nonneg (8*h-1)]
    · nlinarith only [mul_nonneg h0 (show 0 ≤ 1-4*h by linarith only [h4])]
  rw [sixth_moment,abs_mul,abs_neg,abs_of_nonneg h0]
  exact mul_le_of_le_one_right h0 shape

theorem tilt_factorial {w : ℕ → ℝ} (w1 : w 1=0) (unit : ∀ i, w i ∈ Set.Icc (0:ℝ) 1)
    {x : ℝ} (hx : 0≤x) {a : ℕ} (lo : 1≤a) (hi : a≤5) :
    |tiltCoefficient w a x| ≤ exp (-x)/a.factorial := by
  by_cases small : a≤4
  · exact FiveCutoff.tilt_factorial w1 unit hx lo small
  obtain rfl : a=5 := by omega
  have bound := (four_absolute_moments hx).2.2.2
  have diff : |w 5-1| ≤ 1 := abs_le.mpr
    ⟨by linarith [(unit 5).1],by linarith [(unit 5).2]⟩
  rw [tiltCoefficient,abs_div,abs_mul,abs_of_pos (by positivity : (0:ℝ)<(5:ℕ).factorial)]
  exact div_le_div_of_nonneg_right
    ((mul_le_of_le_one_left (abs_nonneg _) diff).trans bound) (by positivity)

theorem drift_factorial {w : ℕ → ℝ} (unit : ∀ i, w i ∈ Set.Icc (0:ℝ) 1)
    {x : ℝ} (hx : 0≤x) {a : ℕ} (lo : 1≤a) (hi : a≤5) :
    |drift w a x| ≤ exp (-x)/a.factorial := by
  by_cases small : a≤4
  · exact FiveCutoff.drift_factorial unit hx lo small
  obtain rfl : a=5 := by omega
  have diff : |w 6-w 5| ≤ 1 := abs_le.mpr
    ⟨by linarith [(unit 6).1,(unit 5).2],by linarith [(unit 6).2,(unit 5).1]⟩
  have hr := (shape_bounds (exp_pos (-x)).le (exp_le_one_iff.mpr (by linarith))).2.1
  rw [drift,abs_div,abs_mul,abs_of_pos (by positivity : (0:ℝ)<(5:ℕ).factorial)]
  exact div_le_div_of_nonneg_right
    ((mul_le_of_le_one_left (abs_nonneg _) diff).trans ((abs_sixth hx).trans hr)) (by positivity)

#print axioms sixth_moment
#print axioms abs_sixth
#print axioms tilt_factorial
#print axioms drift_factorial
end LongCycleBounds.SixCutoff
