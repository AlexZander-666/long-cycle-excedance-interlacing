import LongCycleBounds.SevenOuterScalars
import LongCycleBounds.SevenProfile
import LongCycleBounds.SixOuterLabels

/-! Positive and zero label estimates for the degree-six tilt. -/
noncomputable section

namespace LongCycleBounds.SevenCutoff.Exterior

open Real Finset FixedCutoff MarkedTwo PowerSeries

theorem sextic_bound {N : ℝ} (hN : 96 ≤ N) : sextic N ≤ N^6/600 := by
  have scale : sextic 96 / (96:ℝ)^6 ≤ 1/600 := by
    norm_num [sextic, sum_range_succ, Nat.factorial]
  have h0 : 0 ≤ N := by linarith
  exact (sextic_majorant (by norm_num : (0:ℝ) < 96) hN).trans
    ((mul_le_mul_of_nonneg_right scale (pow_nonneg h0 6)).trans_eq (by ring))

theorem physical_sextic_cost {n : ℕ} (hn : 96 ≤ n) {x : ℝ}
    (outer : 3*sqrt ((n-1:ℕ):ℝ) ≤ x) : exp (-x)*sextic n*(6*(n:ℝ)+1) ≤ 1 := by
  have cap := seventh_power hn outer
  have N : (96:ℝ) ≤ n := by exact_mod_cast hn
  have A := mul_le_mul_of_nonneg_left (sextic_bound N) (exp_pos (-x)).le
  have p := mul_le_mul_of_nonneg_right A (show 0 ≤ 6*(n:ℝ)+1 by positivity)
  have mulN := mul_le_mul_of_nonneg_left (show (1:ℝ) ≤ n by linarith)
    (mul_nonneg (exp_pos (-x)).le (pow_nonneg (Nat.cast_nonneg (α:=ℝ) n) 6))
  nlinarith only [p,cap,mulN]

theorem positive_label {n j d : ℕ} (hn : 96≤n) (hj : 1≤j) (hjn : j≤n)
    {x h : ℝ} (hh : 1≤h) (outer : 3*sqrt ((n-1:ℕ):ℝ)≤x)
    (b : ℕ→ℝ) (cost_bound : ∀ R, 0≤R → cost b R d≤exp (-x)*sextic R) :
    |label b d h j-h^j| ≤ h^j/(6*(n:ℝ)) := by
  let R : ℝ := j/h
  have hpos : 0<h := by linarith
  have R0 : 0≤R := div_nonneg (Nat.cast_nonneg _) hpos.le
  have RN : R≤n := (div_le_iff₀ hpos).mpr <|
    (show (j:ℝ)≤n by exact_mod_cast hjn).trans (le_mul_of_one_le_right (Nat.cast_nonneg _) hh)
  have cap := (cost_bound R R0).trans
    (mul_le_mul_of_nonneg_left (sextic_mono R0 RN) (exp_pos _).le)
  have hN : (96:ℝ)≤n := by exact_mod_cast hn
  have cp := (mul_le_mul_of_nonneg_right cap (show 0≤6*(n:ℝ)+1 by positivity)).trans
    (physical_sextic_cost hn outer)
  have v0 : 0≤cost b R d := sum_nonneg fun i _ ↦ mul_nonneg (abs_nonneg _) (by positivity)
  have small : cost b R d < 1 := by
    nlinarith only [cp,mul_nonneg (show 0≤6*(n:ℝ)-1 by linarith) v0]
  have rel : exp (cost b R d)-1 ≤ 1/(6*(n:ℝ)) := by
    apply (sub_le_sub_right (exp_bound_div_one_sub_of_interval v0 small) 1).trans
    rw [sub_le_iff_le_add,div_le_iff₀ (sub_pos.mpr small)]
    have np : 0<6*(n:ℝ) := by positivity
    apply le_of_mul_le_mul_left (a:=6*(n:ℝ)) _ np
    field_simp [np.ne']
    nlinarith only [cp]
  apply (positive_label_error b d hpos hj).trans
  simpa [R,div_eq_mul_inv] using mul_le_mul_of_nonneg_left rel (pow_nonneg hpos.le j)

theorem zero_label {n j d : ℕ} (hn : 96 ≤ n) (hj : n-7 ≤ j) (hjn : j ≤ n) {x : ℝ}
    (outer : 3*sqrt ((n-1:ℕ):ℝ) ≤ x) (b : ℕ→ℝ)
    (cb : ∀ R, 0 ≤ R → cost b R d ≤ exp (-x)*sextic R) :
    |label b d 0 j| ≤ exp (-x)/(6*(n:ℝ)) := by
  let N : ℝ := n
  let R := 2*N
  have N96 : 96 ≤ N := by dsimp [N]; exact_mod_cast hn
  have np : 0 < N := by dsimp [N]; positivity
  have rp : 0 < R := by dsimp [R]; positivity
  have R96 : 96 ≤ R := by dsimp [R]; linarith
  have pre := (cb R rp.le).trans (mul_le_mul_of_nonneg_left (sextic_bound R96) (exp_pos _).le)
  have bud : exp (-x)*N^7 < 16 := seventh_power hn outer
  have rc : cost b R d ≤ (64/600:ℝ)*exp (-x)*N^6 := by
    dsimp only [R] at pre
    nlinarith only [pre]
  have cov := mul_le_mul_of_nonneg_right rc np.le
  have small : cost b R d ≤ 1/2 := by
    by_contra! bad
    nlinarith only [cov,bud,mul_lt_mul_of_pos_right bad np,N96]
  have v0 : 0 ≤ cost b R d := sum_nonneg fun i _ ↦ mul_nonneg (abs_nonneg _) (pow_nonneg rp.le _)
  have ex := exp_bound_div_one_sub_of_interval v0 (small.trans_lt (by norm_num))
  have near : exp (cost b R d)-1 ≤ 2*cost b R d := by
    apply (sub_le_sub_right ex 1).trans
    rw [sub_le_iff_le_add,div_le_iff₀ (by linarith : 0<1-cost b R d)]
    nlinarith only [mul_nonneg v0 (show 0≤1-2*cost b R d by linarith)]
  have expcap : exp (cost b R d)-1 ≤ exp (-x)*N^6 := by
    linarith only [near,rc,mul_nonneg (exp_pos (-x)).le (pow_nonneg np.le 6)]
  have fj : (j.factorial:ℝ) ≤ N^j := by
    dsimp [N]
    exact_mod_cast j.factorial_le_pow.trans (Nat.pow_le_pow_left hjn j)
  have nj : N^j ≥ 0 := pow_nonneg np.le _
  have power : 6*N^7 ≤ (2:ℝ)^j :=
    (reserve hn).trans (pow_le_pow_right₀ (by norm_num) hj)
  apply (SixCutoff.Exterior.zero_label_nonconstant b d rp (by omega : 0<j)).trans
  rw [div_le_div_iff₀ (pow_pos rp _) (show 0<6*(n:ℝ) by dsimp only [N] at np; positivity)]
  have big := mul_le_mul fj expcap (by linarith [exp_le_exp.mpr v0,exp_zero] :
    0≤exp (cost b R d)-1) nj
  change _ ≤ exp (-x)*R^j
  dsimp only [R]
  rw [mul_pow]
  change (j.factorial:ℝ)*(exp (cost b (2*N) d)-1)*(6*N)≤_
  change (j.factorial:ℝ)*(exp (cost b (2*N) d)-1)≤_ at big
  nlinarith only [mul_le_mul_of_nonneg_right big (show 0≤6*N by positivity),
    mul_le_mul_of_nonneg_right power (mul_nonneg (exp_pos (-x)).le nj)]

#print axioms physical_sextic_cost
#print axioms positive_label
#print axioms zero_label
end LongCycleBounds.SevenCutoff.Exterior
