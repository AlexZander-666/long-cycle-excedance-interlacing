import LongCycleBounds.SevenCycleMoment

/-! Coefficient envelopes for the six insertion offsets at cutoff seven. -/
noncomputable section

namespace LongCycleBounds.SevenCutoff

open Real Finset FixedCutoff Band

theorem tilt_factorial {w : ℕ → ℝ} (one : w 1 = 0) (unit : ∀ a, w a ∈ Set.Icc (0:ℝ) 1)
    {x : ℝ} (hx : 0 ≤ x) {a : ℕ} (lo : 1 ≤ a) (hi : a ≤ 6) :
    |tiltCoefficient w a x| ≤ exp (-x)/a.factorial := by
  by_cases small : a ≤ 5
  · exact SixCutoff.tilt_factorial one unit hx lo small
  obtain rfl : a = 6 := by omega
  have diff : |w 6-1| ≤ 1 := abs_le.mpr
    ⟨by linarith [(unit 6).1], by linarith [(unit 6).2]⟩
  have hr := (FiveCutoff.shape_bounds (exp_pos (-x)).le
    (exp_le_one_iff.mpr (by linarith))).2.1
  rw [tiltCoefficient, abs_div, abs_mul, abs_of_pos (by positivity : (0:ℝ)<(6:ℕ).factorial)]
  exact div_le_div_of_nonneg_right
    ((mul_le_of_le_one_left (abs_nonneg _) diff).trans ((SixCutoff.abs_sixth hx).trans hr))
    (by positivity)

theorem drift_sixth {w : ℕ → ℝ} (unit : ∀ a, w a ∈ Set.Icc (0:ℝ) 1)
    {x : ℝ} (hx : 0 ≤ x) :
    |drift w 6 x| ≤ (21/20)*exp (-x)/(6:ℕ).factorial := by
  have diff : |w 7-w 6| ≤ 1 := abs_le.mpr
    ⟨by linarith [(unit 7).1, (unit 6).2], by linarith [(unit 7).2, (unit 6).1]⟩
  rw [drift, abs_div, abs_mul, abs_of_pos (by positivity : (0:ℝ)<(6:ℕ).factorial)]
  exact div_le_div_of_nonneg_right
    ((mul_le_of_le_one_left (abs_nonneg _) diff).trans (seventh_envelopes hx).2) (by positivity)

theorem drift_factorial {w : ℕ → ℝ} (unit : ∀ a, w a ∈ Set.Icc (0:ℝ) 1)
    {x : ℝ} (hx : 0 ≤ x) {a : ℕ} (lo : 1 ≤ a) (hi : a ≤ 6) :
    |drift w a x| ≤ (21/20)*exp (-x)/a.factorial := by
  by_cases small : a ≤ 5
  · exact (SixCutoff.drift_factorial unit hx lo small).trans (by
      apply div_le_div_of_nonneg_right _ (by positivity)
      linarith only [(exp_pos (-x)).le])
  obtain rfl : a = 6 := by omega
  exact drift_sixth unit hx

/-- The factorial envelope for the degree-six exponential tilt. -/
def sextic (R : ℝ) : ℝ := ∑ a ∈ range 6, R^(a+1)/(a+1).factorial

theorem sextic_nonneg {R : ℝ} (hR : 0 ≤ R) : 0 ≤ sextic R :=
  sum_nonneg fun _ _ ↦ div_nonneg (pow_nonneg hR _) (by positivity)

theorem sextic_mono {R N : ℝ} (hR : 0 ≤ R) (h : R ≤ N) : sextic R ≤ sextic N :=
  sum_le_sum fun _ _ ↦ div_le_div_of_nonneg_right (pow_le_pow_left₀ hR h _) (by positivity)

theorem sextic_majorant {a R : ℝ} (ap : 0 < a) (ha : a ≤ R) :
    sextic R ≤ sextic a / a^6 * R^6 := by
  rw [div_mul_eq_mul_div]
  apply (le_div_iff₀ (pow_pos ap _)).mpr
  unfold sextic
  rw [sum_mul, sum_mul]
  apply sum_le_sum
  intro i hi
  have idx := mem_range.mp hi
  have Rp : 0 < R := ap.trans_le ha
  have pa : a^6 = a^(i+1)*a^(6-(i+1)) := by
    rw [← pow_add, show i+1+(6-(i+1))=6 by omega]
  have pr : R^6 = R^(i+1)*R^(6-(i+1)) := by
    rw [← pow_add, show i+1+(6-(i+1))=6 by omega]
  have mono := pow_le_pow_left₀ ap.le ha (6-(i+1))
  simp only [div_eq_mul_inv]
  nth_rw 1 [pa]
  nth_rw 1 [pr]
  calc
    _ = (R^(i+1) * a^(i+1) * ((i+1).factorial:ℝ)⁻¹) * a^(6-(i+1)) := by ring
    _ ≤ (R^(i+1) * a^(i+1) * ((i+1).factorial:ℝ)⁻¹) * R^(6-(i+1)) :=
      mul_le_mul_of_nonneg_left mono (by positivity)
    _ = _ := by ring

theorem profile_cost {w : ℕ → ℝ} (one : w 1 = 0) (unit : ∀ a, w a ∈ Set.Icc (0:ℝ) 1)
    {x R : ℝ} (hx : 0 ≤ x) (hR : 0 ≤ R) :
    cost (fun a ↦ tiltCoefficient w a x) R 6 ≤ exp (-x)*sextic R := by
  unfold cost sextic
  rw [mul_sum]
  apply sum_le_sum
  intro i hi
  have ib := mem_range.mp hi
  calc
    _ ≤ (exp (-x)/(i+1).factorial)*R^(i+1) :=
      mul_le_mul_of_nonneg_right (tilt_factorial one unit hx (by omega) (by omega))
        (pow_nonneg hR _)
    _ = _ := by ring

#print axioms tilt_factorial
#print axioms drift_sixth
#print axioms drift_factorial
#print axioms sextic_majorant
#print axioms profile_cost
end LongCycleBounds.SevenCutoff
