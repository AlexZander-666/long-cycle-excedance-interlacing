import LongCycleFinite.K7CompactCert.Checks
import LongCycleFinite.K5CompactCert.ExpBounds
import LongCycleBounds.SevenCycleMoment
import LongCycleBounds.SixCutoffMoments
import LongCycleBounds.FiveCellMoments

namespace LongCycleFinite.K7CompactCert.Cell
open K5CompactCert (exp_le_expUpper expTaylor_le_exp)

/-- The rational endpoints of a valid cell enclose the actual value of exp(-x). -/
theorem r_bounds {c : Cell} (hv : c.Valid) {x : ℝ} (ha : (c.a : ℝ) ≤ x)
    (hb : x ≤ (c.b : ℝ)) :
    (c.rLo : ℝ) ≤ Real.exp (-x) ∧ Real.exp (-x) ≤ (c.rHi : ℝ) := by
  obtain ⟨_, ha', hb', hrLo, hr, _⟩ := hv.1
  obtain ⟨hsmall, hlo, hhi, _⟩ := hv.2.1
  have ha0 : 0 ≤ c.a := by rw [ha']; positivity
  have hb0 : 0 ≤ c.b := by rw [hb']; positivity
  have rlo0 : 0 ≤ (c.rLo : ℝ) := by exact_mod_cast hrLo.le
  have rhi0 : 0 ≤ (c.rHi : ℝ) := by exact_mod_cast hrLo.le.trans hr
  rw [Real.exp_neg, ← one_div]
  constructor
  · apply (le_div_iff₀ (Real.exp_pos x)).2
    calc
      (c.rLo : ℝ) * Real.exp x ≤ (c.rLo : ℝ) * (expUpper c.b c.rightHalves : ℝ) :=
        mul_le_mul_of_nonneg_left ((Real.exp_le_exp.mpr hb).trans (exp_le_expUpper hb0 hsmall)) rlo0
      _ ≤ 1 := by simpa using (Rat.cast_le (K := ℝ)).mpr hlo
  · apply (div_le_iff₀ (Real.exp_pos x)).2
    calc
      1 ≤ (c.rHi : ℝ) * (expTaylor c.a 64 : ℝ) :=
        by simpa using (Rat.cast_le (K := ℝ)).mpr hhi
      _ ≤ (c.rHi : ℝ) * Real.exp x :=
        mul_le_mul_of_nonneg_left ((expTaylor_le_exp ha0 64).trans (Real.exp_le_exp.mpr ha)) rhi0

/-- The verified exponential bounds for the cost and loss of a valid cell. -/
theorem exponent_bounds {c : Cell} (hv : c.Valid) :
    Real.exp (c.cost : ℝ) ≤ (c.expCost : ℝ) ∧ Real.exp (c.loss : ℝ) ≤ (c.invD : ℝ) := by
  obtain ⟨_, _, _, hLoss0, _, hLossSmall, hLoss, hCost0, _, hCostSmall, hCost⟩ := hv.2.1
  exact ⟨(exp_le_expUpper hCost0 hCostSmall).trans (Rat.cast_le.mpr hCost),
    (exp_le_expUpper hLoss0 hLossSmall).trans (Rat.cast_le.mpr hLoss)⟩


end LongCycleFinite.K7CompactCert.Cell
noncomputable section
namespace LongCycleBounds.SevenCutoff
open Real FixedCutoff Band PoleBridge LongCycleFinite.K7CompactCert
open FiveCutoff (height imbalance moment_forms shape_bounds height_mono imbalance_anti roundUp_ge)
private theorem pi_enclosure : (piLo : ℝ) ≤ π ∧ π ≤ (piHi : ℝ) := FiveCutoff.pi_enclosure
theorem cell_radii {c : Cell} (hc : c.Geometry) {x : ℝ} (xa : (c.a : ℝ) ≤ x)
    (xb : x ≤ (c.b : ℝ)) :
    0 ≤ x ∧ radius x ≤ (c.rho : ℝ) ∧ radius x < (c.lambda : ℝ)*radius x ∧
      (c.lambda : ℝ)*radius x ≤ ‖PoleBridge.den x 3‖ := by
  obtain ⟨_,ae,_,_,_,_,rp,rbound,lam1,lam3,radiusTest,_,_⟩ := hc
  have a0 : (0:ℚ) ≤ c.a := by rw [ae]; positivity
  have x0 : 0 ≤ x := (show (0:ℝ) ≤ (c.a:ℝ) by exact_mod_cast a0).trans xa
  have b0 := x0.trans xb
  have Rpos : 0 < (c.rho:ℝ) := by exact_mod_cast rp
  have l1 : 1 < (c.lambda:ℝ) := by exact_mod_cast lam1
  have l3 : (c.lambda:ℝ) ≤ 3 := by exact_mod_cast lam3
  have l0 : 0 ≤ (c.lambda:ℝ) := by linarith
  have L := pow_le_pow_left₀ (by norm_num : (0:ℝ) ≤ 1) l1.le 2
  have U := pow_le_pow_left₀ l0 l3 2
  have pl : 0 ≤ (piLo:ℝ) := by norm_num [piLo,LongCycleFinite.K5CompactCert.piLo]
  have P := pow_le_pow_left₀ pl pi_enclosure.1 2
  have Q := pow_le_pow_left₀ pi_pos.le pi_enclosure.2 2
  have X := pow_le_pow_left₀ x0 xb 2
  have rs : radius x ^ 2 = x^2+π^2 := sq_sqrt (by positivity)
  have rr : (c.b:ℝ)^2+(piHi:ℝ)^2 ≤ (c.rho:ℝ)^2 := by exact_mod_cast rbound
  have admiss : (c.lambda:ℝ)^2*((c.b:ℝ)^2+(piLo:ℝ)^2) ≤
      (c.b:ℝ)^2+9*(piLo:ℝ)^2 := by exact_mod_cast radiusTest
  have ds : ‖PoleBridge.den x 3‖^2 = x^2+(3*π)^2 := by
    rw [Complex.sq_norm]
    simp [PoleBridge.den,Complex.normSq_apply,Complex.add_re,Complex.add_im]
    ring
  refine ⟨x0,(sq_le_sq₀ (radius_pos x).le Rpos.le).mp (by linarith only [rs,rr,Q,X]),
    lt_mul_of_one_lt_left (radius_pos x) l1, ?_⟩
  apply (sq_le_sq₀ (mul_nonneg l0 (radius_pos x).le) (norm_nonneg _)).mp
  rw [mul_pow,rs,ds]
  nlinarith only [admiss,
    mul_nonneg (show 0 ≤ (c.lambda:ℝ)^2-1 by linarith only [L]) (sub_nonneg.mpr X),
    mul_nonneg (show 0 ≤ 9-(c.lambda:ℝ)^2 by linarith only [U]) (sub_nonneg.mpr P)]

private theorem bound_affine_abs {a x l h : ℝ} (a0 : 0 ≤ a) (lo : l ≤ x) (hi : x ≤ h) :
    |1-a*x| ≤ max |1-a*l| |1-a*h| := by
  have L := (le_abs_self (1-a*l)).trans (le_max_left |1-a*l| |1-a*h|)
  have H := (neg_le_abs (1-a*h)).trans (le_max_right |1-a*l| |1-a*h|)
  exact abs_le.mpr ⟨by linarith only [H,mul_le_mul_of_nonneg_left hi a0],
    by linarith only [L,mul_le_mul_of_nonneg_left lo a0]⟩

theorem cell_moment_caps {c : Cell} (hc : c.Geometry) {x : ℝ} (hx : 0 ≤ x)
    (rLo : (c.rLo : ℝ) ≤ exp (-x)) (rHi : exp (-x) ≤ (c.rHi : ℝ)) :
    |cycleMoment 2 x| ≤ (c.m2 : ℝ) ∧ |cycleMoment 3 x| ≤ (c.m3 : ℝ) ∧
      |cycleMoment 4 x| ≤ (c.m4 : ℝ) ∧ |cycleMoment 5 x| ≤ (c.m5 : ℝ) := by
  let r := exp (-x)
  have r0 : 0 ≤ r := (exp_pos _).le
  have r1 : r ≤ 1 := exp_le_one_iff.mpr (by linarith)
  obtain ⟨_,_,_,lo0,_,hi1,_⟩ := hc
  have L0 : (0:ℝ) ≤ (c.rLo:ℝ) := by exact_mod_cast lo0.le
  have H1 : (c.rHi:ℝ) ≤ 1 := by exact_mod_cast hi1
  have L : (c.hLo:ℝ) ≤ height r := by
    simpa [Cell.hLo,height] using height_mono L0 rLo r1
  have H : height r ≤ (c.hHi:ℝ) := by
    simpa [Cell.hHi,height] using height_mono r0 rHi H1
  have V : imbalance r ≤ (c.vHi:ℝ) := by
    simpa [Cell.vHi,imbalance] using imbalance_anti L0 rLo
  obtain ⟨h0,_,_,v0,_,_⟩ := shape_bounds r0 r1
  have HV := mul_le_mul H V v0 (h0.trans H)
  have f4 := bound_affine_abs (a:=6) (by norm_num) L H
  have f5 := bound_affine_abs (a:=12) (by norm_num) L H
  obtain ⟨m2,m3,m4,m5⟩ := moment_forms x
  rw [m2,m3,m4,m5]
  change |-(height r)| ≤ _ ∧ |-(height r)*imbalance r| ≤ _ ∧
    |-(height r)*(1-6*height r)| ≤ _ ∧ |-(height r)*imbalance r*(1-12*height r)| ≤ _
  simp only [abs_mul,abs_neg,abs_of_nonneg h0,abs_of_nonneg v0]
  refine ⟨H.trans (by exact_mod_cast roundUp_ge c.hHi),
    HV.trans (by exact_mod_cast roundUp_ge (c.hHi*c.vHi)), ?_, ?_⟩
  · apply (mul_le_mul H f4 (abs_nonneg _) (h0.trans H)).trans
    exact_mod_cast roundUp_ge (c.hHi * max |1-6*c.hLo| |1-6*c.hHi|)
  · apply (mul_le_mul HV f5 (abs_nonneg _) ((mul_nonneg h0 v0).trans HV)).trans
    exact_mod_cast roundUp_ge (c.hHi*c.vHi * max |1-12*c.hLo| |1-12*c.hHi|)


theorem cell_sixth {c : Cell} (hc : c.Geometry) {x : ℝ} (hx : 0≤x)
    (hi : exp (-x) ≤ (c.rHi:ℝ)) : |cycleMoment 6 x| ≤ (c.m6:ℝ) := by
  have hi1 : (c.rHi:ℝ) ≤ 1 := by exact_mod_cast hc.2.2.2.2.2.1
  have u := height_mono (exp_pos (-x)).le hi hi1
  have h : height (exp (-x)) ≤ (c.hHi:ℝ) := by simpa [Cell.hHi,height] using u
  exact (SixCutoff.abs_sixth hx).trans (h.trans (by exact_mod_cast roundUp_ge c.hHi))

theorem cell_seventh {c : Cell} {x : ℝ} (hx : 0 ≤ x)
    (hi : exp (-x) ≤ (c.rHi : ℝ)) : |cycleMoment 7 x| ≤ (c.m7 : ℝ) := by
  simpa [Cell.m7] using (seventh_envelopes hx).2.trans
    (mul_le_mul_of_nonneg_left hi (by norm_num : (0:ℝ) ≤ 21/20))

#print axioms cell_seventh
end LongCycleBounds.SevenCutoff
