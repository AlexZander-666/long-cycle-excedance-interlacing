import LongCycleBounds.FortyEightPeak
import LongCycleBounds.SevenOuterLabels
import LongCycleBounds.FixedCutoffAnalyticAssembly
import LongCycleBounds.CycleProfileInsertion

/-! Exterior sign for the genuine short-cycle weights at size 96 and beyond. -/
noncomputable section
namespace LongCycleBounds.SevenCutoff.Exterior
open Real Finset Outer FixedCutoff MarkedTwo PowerSeries

private theorem outer_x {p : ℕ} (hp : 96≤p+1) {x : ℝ} (outer : 3*sqrt (p:ℝ)≤x) :
    2≤x := by
  have pn : (1:ℝ)≤p := by exact_mod_cast (show 1≤p by omega)
  have h := sqrt_le_sqrt pn
  rw [sqrt_one] at h
  linarith


private theorem raw_outer_error {n j d : ℕ} (hn : 96≤n) (hj : n-7≤j) (hjn : j≤n) {x : ℝ} (b : ℕ→ℝ)
    (cost_bound : ∀ R, 0 ≤ R → cost b R d ≤ exp (-x)*sextic R) (outer : 3*sqrt ((n-1:ℕ):ℝ)≤x) :
    |raw b d j x+Outer.moment j x| ≤ (exp (-x)+∑' i, weight j x i)/(6*(n:ℝ)) := by
  have hp0 : (0:ℝ)<((n-1:ℕ):ℝ) := by exact_mod_cast (show 0<n-1 by omega)
  have hx : 0<x := lt_of_lt_of_le (by positivity) outer
  let t := time x
  let T (i : ℕ) := label b d i j
  have hnorm : ‖t‖ < 1 := by simp [t,time,Real.norm_eq_abs,exp_lt_one_iff,hx]
  have hs := logistic_label_sum b d hnorm j
  have sh := hs.summable.tsum_eq_zero_add
  rw [hs.tsum_eq] at sh
  have original : raw b d j x = T 0 + ∑' i : ℕ, t^(i+1)*T (i+1) := by
    simpa [raw,T,t] using sh
  let E (i : ℕ) := t^(i+1)*T (i+1)+(-1:ℝ)^i*weight j x i
  have bound (i : ℕ) : ‖E i‖ ≤ weight j x i/(6*(n:ℝ)) := by
    have bound := positive_label hn (by omega : 1≤j) hjn
      (h:=(i+1:ℕ)) (by exact_mod_cast (show 1≤ i+1 by omega)) outer b cost_bound
    change |T (i+1)-((i+1:ℕ):ℝ)^j|≤_/ _ at bound
    have e : E i = -((-1:ℝ)^i)*(exp (-x))^(i+1)*(T (i+1)-((i+1:ℕ):ℝ)^j) := by
      have tv : t=(-1)*exp (-x) := by simp [t,time]
      simp only [E,tv,mul_pow,weight,Nat.cast_succ,pow_succ (-1:ℝ) i]
      ring
    rw [e,Real.norm_eq_abs,abs_mul,abs_mul]
    simp only [abs_neg,abs_pow,abs_one,one_pow,one_mul,abs_of_pos (exp_pos _)]
    unfold weight
    rw [Nat.cast_succ] at bound ⊢
    calc
      _ ≤ (exp (-x))^(i+1)*((((i:ℝ)+1)^j)/(6*(n:ℝ))) := mul_le_mul_of_nonneg_left bound (by positivity)
      _ = _ := by ring
  have hrs : Summable (fun i : ℕ ↦ weight j x i/(6*(n:ℝ))) := (summable_weight j x hx).div_const _
  have herr := (norm_tsum_le_tsum_norm (hrs.of_nonneg_of_le (fun _ ↦ norm_nonneg _) bound)).trans
    ((hrs.of_nonneg_of_le (fun _ ↦ norm_nonneg _) bound).tsum_le_tsum bound hrs)
  have hraw : raw b d j x+Outer.moment j x=T 0+∑' i, E i := by
    rw [original,add_assoc,Outer.moment]
    congr 1
    exact (((summable_nat_add_iff 1).mpr hs.summable).tsum_add (summable_signed_weight j x hx)).symm
  rw [hraw]
  rw [Real.norm_eq_abs] at herr
  have zero : |T 0| ≤ exp (-x)/(6*(n:ℝ)) := by
    simpa only [T, Nat.cast_zero] using zero_label hn hj hjn outer b cost_bound
  rw [tsum_div_const] at herr
  rw [add_div]
  exact (abs_add_le ..).trans (add_le_add zero herr)


private theorem smaller_mass (p j : ℕ) (hp : 48≤p) (hj : j≤p) (x : ℝ) (hx : 0<x)
    (region : 3*sqrt p≤x) : ∑' i, weight j x i ≤ 4*weight p x (mode p x hx) := by
  apply le_trans ((summable_weight j x hx).tsum_le_tsum _ (summable_weight p x hx))
    (FortyEight.mass_at_peak p hp x hx (by linarith [sqrt_nonneg (p:ℝ)]))
  intro i
  unfold weight
  exact mul_le_mul_of_nonneg_right (pow_le_pow_right₀ (by linarith [Nat.cast_nonneg (α:=ℝ) i]) hj) (by positivity)

private theorem peak_label_bound (p : ℕ) (hp : 48≤p) (x : ℝ) (hx : 0<x)
    (region : (29/10:ℝ)*sqrt p ≤ x) :
    (mode p x hx:ℝ)+2 ≤ ((p:ℝ)+1)/8 := by
  have a := FortyEight.mode_one_bound p hp x hx region
  have pn : (48:ℝ)≤p := by exact_mod_cast hp
  have sp : (6:ℝ) ≤ sqrt p := (Real.le_sqrt (by norm_num) (Nat.cast_nonneg p)).mpr (by linarith)
  have u := mul_le_mul_of_nonneg_right sp (sqrt_nonneg (p:ℝ))
  rw [←sq,Real.sq_sqrt (Nat.cast_nonneg p)] at u
  linarith only [a,u,pn]

private theorem successor_mass (p : ℕ) (hp : 48≤p) (x : ℝ) (hx : 0<x)
    (region : 3*sqrt p≤x) : ∑' i, weight (p+1) x i ≤ (((p:ℝ)+1)/2)*weight p x (mode p x hx) := by
  let m := mode (p+1) x hx
  have mass := FortyEight.mass_at_peak (p+1) (by omega) x hx (FortyEight.region_next hp region)
  have ml := peak_label_bound (p+1) (by omega) x hx (FortyEight.region_next hp region)
  change (m:ℝ)+2 ≤ (((p+1:ℕ):ℝ)+1)/8 at ml
  rw [Nat.cast_succ] at ml
  have eq : weight (p+1) x m = ((m:ℝ)+1)*weight p x m := by unfold weight; rw [pow_succ]; ring
  change _ ≤ 4*weight (p+1) x m at mass
  rw [eq,←mul_assoc] at mass
  exact mass.trans (mul_le_mul (by linarith only [ml]) (weight_le_mode p x hx m)
    (weight_pos ..).le (by positivity))

private theorem peak_small {p j d : ℕ} (hn : 96≤p+1) 
    (hj : p+1-7≤j) (hjn : j≤p) {x : ℝ} (b : ℕ→ℝ)
    (cost_bound : ∀ R, 0 ≤ R → cost b R d≤exp (-x)*sextic R)
    (outer : 3*sqrt (p:ℝ)≤x) :
    ((p:ℝ)+1)*|raw b d j x+Outer.moment j x| ≤ weight p x (mode p x (by linarith [outer_x hn outer])) := by
  have hx : 0<x := by linarith [outer_x hn outer]
  have err := raw_outer_error hn hj (by omega : j≤p+1) b cost_bound (by simpa using outer)
  have mass := smaller_mass p j (by omega) hjn x hx outer
  have rr := weight_le_mode p x hx 0
  simp only [weight, Nat.cast_zero, zero_add,one_pow,one_mul,pow_one] at rr
  change exp (-x)≤weight p x (mode p x hx) at rr
  rw [Nat.cast_succ] at err
  have main := (le_div_iff₀ (by positivity)).mp err
  nlinarith only [main,mass,rr,(weight_pos p x (mode p x hx)).le]

private theorem peak_successor {p d : ℕ} (hn : 96≤p+1) 
    {x : ℝ} (b : ℕ→ℝ)
    (cost_bound : ∀ R, 0 ≤ R → cost b R d≤exp (-x)*sextic R)
    (outer : 3*sqrt (p:ℝ)≤x) :
    |raw b d (p+1) x+Outer.moment (p+1) x| ≤ weight p x (mode p x (by linarith [outer_x hn outer]))/8 := by
  have hx : 0<x := by linarith [outer_x hn outer]
  have err := raw_outer_error hn (by omega : p+1-7≤p+1) le_rfl b cost_bound (by simpa using outer)
  have mass := successor_mass p (by omega) x hx outer
  have rr := weight_le_mode p x hx 0
  have eq : weight p x 0=exp (-x) := by simp [weight]
  rw [eq] at rr
  rw [Nat.cast_succ] at err
  have main := (le_div_iff₀ (by positivity)).mp err
  apply (le_div_iff₀ (by norm_num)).mpr
  apply le_of_mul_le_mul_right (a:=6*((p:ℝ)+1)) _ (by positivity)
  have h : (48:ℝ) ≤ p := by exact_mod_cast (show 48≤p by omega)
  nlinarith only [main,mass,rr,(weight_pos p x (mode p x hx)).le,
    mul_nonneg (sub_nonneg.mpr h) (weight_pos p x (mode p x hx)).le]

theorem insertion_gap {p : ℕ} (hn : 96≤p+1)  {x : ℝ} (b C : ℕ→ℝ)
    (cost_bound : ∀ R, 0 ≤ R → cost b R 6 ≤ exp (-x)*sextic R) 
    (hC : ∀ i, 1 ≤ i → i ≤ 6 → |C i|≤(21/20)*exp (-x)/i.factorial)
    (outer : 3*sqrt (p:ℝ)≤x) (zero : raw b 6 p x=0) :
    |∑ i ∈ range 6, (p.descFactorial (i+1):ℝ)*C (i+1)*raw b 6 (p-(i+1)) x| <
      |raw b 6 (p+1) x| := by
  let N := (p:ℝ)+1
  have hn' : 96≤p+1 := hn
  have nr : 96≤N := by dsimp [N];exact_mod_cast hn'
  have cut : 3*sqrt (p:ℝ)≤x := outer
  have x2 := outer_x hn' cut
  have hx : 0<x := by linarith
  let M := mode p x hx
  let W := weight p x M
  have wp : 0<W := weight_pos ..
  have prev : raw b 6 p x=0 := zero
  have small (j : ℕ) (hj : p+1-7≤j) (le : j≤p) :
      N*|raw b 6 j x+Outer.moment j x| ≤ W := peak_small hn' hj le b cost_bound cut
  have eps (j : ℕ) (hj : p+1-7≤j) (le : j≤p+1) :
      |raw b 6 j x+Outer.moment j x| ≤ W/8 := by
    by_cases h : j≤p
    · nlinarith only [small j hj h,mul_nonneg (show 0≤N-8 by linarith)
        (abs_nonneg (raw b 6 j x+Outer.moment j x))]
    · have ej : j=p+1 := by omega
      subst j
      exact peak_successor hn' b cost_bound cut
  have next := small p (by omega) le_rfl
  rw [prev,zero_add] at next
  have split : (29/10:ℝ)*sqrt (p:ℝ)≤x := by linarith [sqrt_nonneg (p:ℝ)]
  have pm : (M:ℝ)+2 ≤ N/8 := peak_label_bound p (by omega) x hx split
  have rob := robust_derivative_of_tails p x hx (FortyEight.neighbors_min_le p (by omega) x hx split)
    (FortyEight.both_geometric p (by omega) x hx split)
  change W/2 < |Outer.moment (p+1) x|+((M:ℝ)+2)*|Outer.moment p x| at rob
  have big : W/4 < |raw b 6 (p+1) x| := by
    have diff := abs_sub (raw b 6 (p+1) x+Outer.moment (p+1) x) (raw b 6 (p+1) x)
    rw [add_sub_cancel_left] at diff
    nlinarith only [diff,rob,next,mul_le_mul_of_nonneg_right pm (abs_nonneg (Outer.moment p x)),
      eps (p+1) (by omega) le_rfl]
  have short (j : ℕ) (hj : p+1-7≤j) (le : j≤p) : |raw b 6 j x| ≤ 2*W := by
    have plain := signed_weight_bound j x hx
    change |Outer.moment j x| ≤ weight j x (mode j x hx) at plain
    let i := mode j x hx
    have weight_le : weight j x i≤weight p x i := by
      unfold weight
      exact mul_le_mul_of_nonneg_right (pow_le_pow_right₀ (by linarith [Nat.cast_nonneg (α:=ℝ) i]) le)
        (by positivity)
    have bound := plain.trans (weight_le.trans (weight_le_mode p x hx i))
    have diff := abs_sub (raw b 6 j x+Outer.moment j x) (Outer.moment j x)
    rw [add_sub_cancel_right] at diff
    linarith only [diff,eps j hj (by omega),bound,wp]
  have factor (i : ℕ) (hi : i ∈ range 6) :
      |(p.descFactorial (i+1):ℝ)*C (i+1)*raw b 6 (p-(i+1)) x| ≤
        ((21/20)*exp (-x)*N^(i+1)/(i+1).factorial)*(2*W) := by
    have ib := mem_range.mp hi
    have df : (p.descFactorial (i+1):ℝ) ≤ N^(i+1) :=
      (by exact_mod_cast Nat.descFactorial_le_pow p (i+1) :
        (p.descFactorial (i+1):ℝ) ≤ (p:ℝ)^(i+1)).trans
        (pow_le_pow_left₀ (by positivity) (show (p:ℝ)≤N by dsimp [N];linarith) _)
    rw [abs_mul,abs_mul,abs_of_nonneg (by positivity : 0≤(p.descFactorial (i+1):ℝ))]
    have u := mul_le_mul df (hC (i+1) (by omega) (by omega)) (abs_nonneg _) (by positivity)
    have both := mul_le_mul u (short (p-(i+1)) (by omega) (Nat.sub_le ..)) (abs_nonneg _)
      (mul_nonneg (pow_nonneg (show 0≤N by linarith) _) (by positivity))
    exact le_trans both (by ring_nf; rfl)
  have mass := (abs_sum_le_sum_abs ..).trans (sum_le_sum factor)
  have id : (∑ i∈range 6, ((21/20)*exp (-x)*N^(i+1)/(i+1).factorial)*(2*W)) =
      (21/20)*exp (-x)*sextic N*(2*W) := by
    norm_num [sum_range_succ,sextic,Nat.factorial]
    ring
  rw [id] at mass
  have bud := physical_sextic_cost hn' (by simpa using outer)
  rw [Nat.cast_succ] at bud
  change exp (-x)*sextic N*(6*N+1)≤1 at bud
  have pos : 0≤exp (-x)*sextic N := mul_nonneg (exp_pos _).le (sextic_nonneg (by dsimp [N]; positivity))
  have bb : (21/20)*exp (-x)*sextic N ≤ 1/8 := by
    have hN : 9≤6*((p:ℝ)+1)+1 := by dsimp [N] at nr; linarith
    nlinarith only [bud,mul_le_mul_of_nonneg_left hN pos]
  exact mass.trans_lt ((show (21/20)*exp (-x)*sextic N*(2*W)≤W/4 by
    nlinarith only [mul_le_mul_of_nonneg_right bb wp.le]).trans_lt big)

end LongCycleBounds.SevenCutoff.Exterior

namespace LongCycleBounds.SevenCutoff
open Real Finset FixedCutoff MarkedTwo CycleProfile

/-- The five short-cycle marks vary independently over their entire closed cube.
The lower row has index p and the upper row has index p+1. -/
theorem exterior_sign {p : ℕ} (hn : 96≤p+1) (w : ℕ→ℝ) (one : w 1=0)
    (tail : ∀ a≥7, w a=1) (unit : ∀ a,w a∈Set.Icc (0:ℝ) 1) {x : ℝ}
    (outer : 3*sqrt (p:ℝ)≤x) (zero : CycleProfile.normalizedRow w p x=0) :
    0<CycleProfile.normalizedRow w (p+1) x*(-deriv (CycleProfile.normalizedRow w p) x) := by
  have hx : 0≤x := le_trans (by positivity) outer
  let b := fun a ↦ tiltCoefficient w a x
  let C := fun a ↦ drift w a x
  have hC (i : ℕ) (hi : 1 ≤ i) (hi5 : i≤6) : |C i|≤(21/20)*exp (-x)/i.factorial := drift_factorial unit hx hi hi5
  have rz : raw b 6 p x=0 := by
    have a := raw_eq_profile (by decide : 2≤7) w one tail hx p
    rw [zero] at a
    exact (mul_eq_zero.mp a).resolve_left (by unfold MarkedTwo.time;linarith [exp_pos (-x)])
  apply raw_gap_to_normalized_sign (by decide : 2≤7) w one tail hx
    (CycleProfile.normalizedRow_insertion (by decide : 3≤7) (by omega) w one tail x)
  exact Exterior.insertion_gap hn b C (fun _ hR ↦ profile_cost one unit hx hR) hC outer rz

#print axioms exterior_sign
end LongCycleBounds.SevenCutoff
