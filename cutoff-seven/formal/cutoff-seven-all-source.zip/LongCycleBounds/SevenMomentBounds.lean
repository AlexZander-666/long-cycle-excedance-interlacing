import Mathlib.Tactic

namespace LongCycleBounds.SevenCutoff
def numerator (r : ℝ) := 1-57*r+302*r^2-302*r^3+57*r^4-r^5

private theorem height_plus0 (r : ℝ) (l : 0≤r) (h : r≤(1/4:ℝ)) :
    0 ≤ (11/6:ℝ)*(1+r)^5 + numerator r := by
  have lo := sub_nonneg.mpr l
  have hi := sub_nonneg.mpr h
  calc
    0 ≤ (8704/3:ℝ)*(r-0)^0*((1/4:ℝ)-r)^5 +
      (6784/3:ℝ)*(r-0)^1*((1/4:ℝ)-r)^4 +
      (1600/3:ℝ)*(r-0)^2*((1/4:ℝ)-r)^3 +
      (37520/3:ℝ)*(r-0)^3*((1/4:ℝ)-r)^2 +
      (54650/3:ℝ)*(r-0)^4*((1/4:ℝ)-r)^1 +
      (41305/6:ℝ)*(r-0)^5*((1/4:ℝ)-r)^0 := by positivity
    _ = _ := by unfold numerator; ring

private theorem height_plus1 (r : ℝ) (l : (1/4:ℝ)≤r) (h : r≤(1/2:ℝ)) :
    0 ≤ (11/6:ℝ)*(1+r)^5 + numerator r := by
  have lo := sub_nonneg.mpr l
  have hi := sub_nonneg.mpr h
  calc
    0 ≤ (41305/6:ℝ)*(r-(1/4:ℝ))^0*((1/2:ℝ)-r)^5 +
      50625*(r-(1/4:ℝ))^1*((1/2:ℝ)-r)^4 +
      142140*(r-(1/4:ℝ))^2*((1/2:ℝ)-r)^3 +
      188040*(r-(1/4:ℝ))^3*((1/2:ℝ)-r)^2 +
      118008*(r-(1/4:ℝ))^4*((1/2:ℝ)-r)^1 +
      28368*(r-(1/4:ℝ))^5*((1/2:ℝ)-r)^0 := by positivity
    _ = _ := by unfold numerator; ring

private theorem height_plus2 (r : ℝ) (l : (1/2:ℝ)≤r) (h : r≤1) :
    0 ≤ (11/6:ℝ)*(1+r)^5 + numerator r := by
  have lo := sub_nonneg.mpr l
  have hi := sub_nonneg.mpr h
  calc
    0 ≤ (1773/2:ℝ)*(r-(1/2:ℝ))^0*(1-r)^5 +
      5922*(r-(1/2:ℝ))^1*(1-r)^4 +
      14784*(r-(1/2:ℝ))^2*(1-r)^3 +
      17088*(r-(1/2:ℝ))^3*(1-r)^2 +
      9216*(r-(1/2:ℝ))^4*(1-r)^1 +
      (5632/3:ℝ)*(r-(1/2:ℝ))^5*(1-r)^0 := by positivity
    _ = _ := by unfold numerator; ring

theorem height_plus (r : ℝ) (l : 0≤r) (h : r≤1) : 0≤(11/6:ℝ)*(1+r)^5 + numerator r := by
  by_cases h0 : r≤(1/4:ℝ)
  · exact height_plus0 r l h0
  by_cases h1 : r≤(1/2:ℝ)
  · exact height_plus1 r (le_of_not_ge h0) h1
  exact height_plus2 r (le_of_not_ge h1) h

private theorem height_minus0 (r : ℝ) (l : 0≤r) (h : r≤(1/2:ℝ)) :
    0 ≤ (11/6:ℝ)*(1+r)^5 - numerator r := by
  have lo := sub_nonneg.mpr l
  have hi := sub_nonneg.mpr h
  calc
    0 ≤ (80/3:ℝ)*(r-0)^0*((1/2:ℝ)-r)^5 +
      1192*(r-0)^1*((1/2:ℝ)-r)^4 +
      2232*(r-0)^2*((1/2:ℝ)-r)^3 +
      1092*(r-0)^3*((1/2:ℝ)-r)^2 +
      27*(r-0)^4*((1/2:ℝ)-r)^1 +
      (9/2:ℝ)*(r-0)^5*((1/2:ℝ)-r)^0 := by positivity
    _ = _ := by unfold numerator; ring

private theorem height_minus1 (r : ℝ) (l : (1/2:ℝ)≤r) (h : r≤1) :
    0 ≤ (11/6:ℝ)*(1+r)^5 - numerator r := by
  have lo := sub_nonneg.mpr l
  have hi := sub_nonneg.mpr h
  calc
    0 ≤ (9/2:ℝ)*(r-(1/2:ℝ))^0*(1-r)^5 +
      18*(r-(1/2:ℝ))^1*(1-r)^4 +
      1056*(r-(1/2:ℝ))^2*(1-r)^3 +
      4032*(r-(1/2:ℝ))^3*(1-r)^2 +
      4864*(r-(1/2:ℝ))^4*(1-r)^1 +
      (5632/3:ℝ)*(r-(1/2:ℝ))^5*(1-r)^0 := by positivity
    _ = _ := by unfold numerator; ring

theorem height_minus (r : ℝ) (l : 0≤r) (h : r≤1) : 0≤(11/6:ℝ)*(1+r)^5 - numerator r := by
  by_cases h0 : r≤(1/2:ℝ)
  · exact height_minus0 r l h0
  exact height_minus1 r (le_of_not_ge h0) h

private theorem radius_plus0 (r : ℝ) (l : 0≤r) (h : r≤(1/16:ℝ)) :
    0 ≤ (21/20:ℝ)*(1+r)^7 + numerator r := by
  have lo := sub_nonneg.mpr l
  have hi := sub_nonneg.mpr h
  calc
    0 ≤ (2751463424/5:ℝ)*(r-0)^0*((1/16:ℝ)-r)^7 +
      (15095300096/5:ℝ)*(r-0)^1*((1/16:ℝ)-r)^6 +
      (34490023936/5:ℝ)*(r-0)^2*((1/16:ℝ)-r)^5 +
      8446984192*(r-0)^3*((1/16:ℝ)-r)^4 +
      5929229312*(r-0)^4*((1/16:ℝ)-r)^3 +
      (11780410688/5:ℝ)*(r-0)^5*((1/16:ℝ)-r)^2 +
      (2423503052/5:ℝ)*(r-0)^6*((1/16:ℝ)-r)^1 +
      (802020933/20:ℝ)*(r-0)^7*((1/16:ℝ)-r)^0 := by positivity
    _ = _ := by unfold numerator; ring

private theorem radius_plus1 (r : ℝ) (l : (1/16:ℝ)≤r) (h : r≤(3/32:ℝ)) :
    0 ≤ (21/20:ℝ)*(1+r)^7 + numerator r := by
  have lo := sub_nonneg.mpr l
  have hi := sub_nonneg.mpr h
  calc
    0 ≤ (25664669856/5:ℝ)*(r-(1/16:ℝ))^0*((3/32:ℝ)-r)^7 +
      22874967632*(r-(1/16:ℝ))^1*((3/32:ℝ)-r)^6 +
      38738206952*(r-(1/16:ℝ))^2*((3/32:ℝ)-r)^5 +
      29966550916*(r-(1/16:ℝ))^3*((3/32:ℝ)-r)^4 +
      10334099750*(r-(1/16:ℝ))^4*((3/32:ℝ)-r)^3 +
      3252186655*(r-(1/16:ℝ))^5*((3/32:ℝ)-r)^2 +
      (5993022415/2:ℝ)*(r-(1/16:ℝ))^6*((3/32:ℝ)-r)^1 +
      (4432186715/4:ℝ)*(r-(1/16:ℝ))^7*((3/32:ℝ)-r)^0 := by positivity
    _ = _ := by unfold numerator; ring

private theorem radius_plus2 (r : ℝ) (l : (3/32:ℝ)≤r) (h : r≤(1/8:ℝ)) :
    0 ≤ (21/20:ℝ)*(1+r)^7 + numerator r := by
  have lo := sub_nonneg.mpr l
  have hi := sub_nonneg.mpr h
  calc
    0 ≤ (4432186715/4:ℝ)*(r-(3/32:ℝ))^0*((1/8:ℝ)-r)^7 +
      12516142295*(r-(3/32:ℝ))^1*((1/8:ℝ)-r)^6 +
      60369973180*(r-(3/32:ℝ))^2*((1/8:ℝ)-r)^5 +
      152650164400*(r-(3/32:ℝ))^3*((1/8:ℝ)-r)^4 +
      218445566016*(r-(3/32:ℝ))^4*((1/8:ℝ)-r)^3 +
      178662315264*(r-(3/32:ℝ))^5*((1/8:ℝ)-r)^2 +
      78079251456*(r-(3/32:ℝ))^6*((1/8:ℝ)-r)^1 +
      (70871076864/5:ℝ)*(r-(3/32:ℝ))^7*((1/8:ℝ)-r)^0 := by positivity
    _ = _ := by unfold numerator; ring

private theorem radius_plus3 (r : ℝ) (l : (1/8:ℝ)≤r) (h : r≤(1/4:ℝ)) :
    0 ≤ (21/20:ℝ)*(1+r)^7 + numerator r := by
  have lo := sub_nonneg.mpr l
  have hi := sub_nonneg.mpr h
  calc
    0 ≤ (17302509/20:ℝ)*(r-(1/8:ℝ))^0*((1/4:ℝ)-r)^7 +
      (22434147/2:ℝ)*(r-(1/8:ℝ))^1*((1/4:ℝ)-r)^6 +
      56796261*(r-(1/8:ℝ))^2*((1/4:ℝ)-r)^5 +
      145124814*(r-(1/8:ℝ))^3*((1/4:ℝ)-r)^4 +
      206654380*(r-(1/8:ℝ))^4*((1/4:ℝ)-r)^3 +
      167090120*(r-(1/8:ℝ))^5*((1/4:ℝ)-r)^2 +
      71981680*(r-(1/8:ℝ))^6*((1/4:ℝ)-r)^1 +
      12865440*(r-(1/8:ℝ))^7*((1/4:ℝ)-r)^0 := by positivity
    _ = _ := by unfold numerator; ring

private theorem radius_plus4 (r : ℝ) (l : (1/4:ℝ)≤r) (h : r≤(1/2:ℝ)) :
    0 ≤ (21/20:ℝ)*(1+r)^7 + numerator r := by
  have lo := sub_nonneg.mpr l
  have hi := sub_nonneg.mpr h
  calc
    0 ≤ (402045/4:ℝ)*(r-(1/4:ℝ))^0*((1/2:ℝ)-r)^7 +
      (1972045/2:ℝ)*(r-(1/4:ℝ))^1*((1/2:ℝ)-r)^6 +
      3973345*(r-(1/4:ℝ))^2*((1/2:ℝ)-r)^5 +
      8554370*(r-(1/4:ℝ))^3*((1/2:ℝ)-r)^4 +
      10694748*(r-(1/4:ℝ))^4*((1/2:ℝ)-r)^3 +
      7812408*(r-(1/4:ℝ))^5*((1/2:ℝ)-r)^2 +
      3103920*(r-(1/4:ℝ))^6*((1/2:ℝ)-r)^1 +
      (2598624/5:ℝ)*(r-(1/4:ℝ))^7*((1/2:ℝ)-r)^0 := by positivity
    _ = _ := by unfold numerator; ring

private theorem radius_plus5 (r : ℝ) (l : (1/2:ℝ)≤r) (h : r≤1) :
    0 ≤ (21/20:ℝ)*(1+r)^7 + numerator r := by
  have lo := sub_nonneg.mpr l
  have hi := sub_nonneg.mpr h
  calc
    0 ≤ (81207/20:ℝ)*(r-(1/2:ℝ))^0*(1-r)^7 +
      (183843/5:ℝ)*(r-(1/2:ℝ))^1*(1-r)^6 +
      (692832/5:ℝ)*(r-(1/2:ℝ))^2*(1-r)^5 +
      283344*(r-(1/2:ℝ))^3*(1-r)^4 +
      342400*(r-(1/2:ℝ))^4*(1-r)^3 +
      (1233664/5:ℝ)*(r-(1/2:ℝ))^5*(1-r)^2 +
      (495104/5:ℝ)*(r-(1/2:ℝ))^6*(1-r)^1 +
      (86016/5:ℝ)*(r-(1/2:ℝ))^7*(1-r)^0 := by positivity
    _ = _ := by unfold numerator; ring

theorem radius_plus (r : ℝ) (l : 0≤r) (h : r≤1) : 0≤(21/20:ℝ)*(1+r)^7 + numerator r := by
  by_cases h0 : r≤(1/16:ℝ)
  · exact radius_plus0 r l h0
  by_cases h1 : r≤(3/32:ℝ)
  · exact radius_plus1 r (le_of_not_ge h0) h1
  by_cases h2 : r≤(1/8:ℝ)
  · exact radius_plus2 r (le_of_not_ge h1) h2
  by_cases h3 : r≤(1/4:ℝ)
  · exact radius_plus3 r (le_of_not_ge h2) h3
  by_cases h4 : r≤(1/2:ℝ)
  · exact radius_plus4 r (le_of_not_ge h3) h4
  exact radius_plus5 r (le_of_not_ge h4) h

private theorem radius_minus0 (r : ℝ) (l : 0≤r) (h : r≤(1/2:ℝ)) :
    0 ≤ (21/20:ℝ)*(1+r)^7 - numerator r := by
  have lo := sub_nonneg.mpr l
  have hi := sub_nonneg.mpr h
  calc
    0 ≤ (32/5:ℝ)*(r-0)^0*((1/2:ℝ)-r)^7 +
      (20816/5:ℝ)*(r-0)^1*((1/2:ℝ)-r)^6 +
      (79432/5:ℝ)*(r-0)^2*((1/2:ℝ)-r)^5 +
      22628*(r-0)^3*((1/2:ℝ)-r)^4 +
      14526*(r-0)^4*((1/2:ℝ)-r)^3 +
      (22263/5:ℝ)*(r-0)^5*((1/2:ℝ)-r)^2 +
      (13563/10:ℝ)*(r-0)^6*((1/2:ℝ)-r)^1 +
      (10647/20:ℝ)*(r-0)^7*((1/2:ℝ)-r)^0 := by positivity
    _ = _ := by unfold numerator; ring

private theorem radius_minus1 (r : ℝ) (l : (1/2:ℝ)≤r) (h : r≤1) :
    0 ≤ (21/20:ℝ)*(1+r)^7 - numerator r := by
  have lo := sub_nonneg.mpr l
  have hi := sub_nonneg.mpr h
  calc
    0 ≤ (10647/20:ℝ)*(r-(1/2:ℝ))^0*(1-r)^7 +
      (30483/5:ℝ)*(r-(1/2:ℝ))^1*(1-r)^6 +
      (164472/5:ℝ)*(r-(1/2:ℝ))^2*(1-r)^5 +
      97680*(r-(1/2:ℝ))^3*(1-r)^4 +
      165632*(r-(1/2:ℝ))^4*(1-r)^3 +
      (798464/5:ℝ)*(r-(1/2:ℝ))^5*(1-r)^2 +
      (408064/5:ℝ)*(r-(1/2:ℝ))^6*(1-r)^1 +
      (86016/5:ℝ)*(r-(1/2:ℝ))^7*(1-r)^0 := by positivity
    _ = _ := by unfold numerator; ring

theorem radius_minus (r : ℝ) (l : 0≤r) (h : r≤1) : 0≤(21/20:ℝ)*(1+r)^7 - numerator r := by
  by_cases h0 : r≤(1/2:ℝ)
  · exact radius_minus0 r l h0
  exact radius_minus1 r (le_of_not_ge h0) h

end LongCycleBounds.SevenCutoff
