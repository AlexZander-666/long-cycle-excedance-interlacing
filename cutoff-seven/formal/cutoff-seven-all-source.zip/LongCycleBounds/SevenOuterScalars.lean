import LongCycleBounds.OuterDecayEnvelope
import LongCycleFinite.K5CompactCert.ExpBounds

/-! Rational anchors for the exterior at upper size 96. -/
namespace LongCycleBounds.SevenCutoff.Exterior

open Real LongCycleFinite.K5CompactCert

private theorem anchor_exp :
    (1 + (487 / 50 : ℝ)^2)^7/16 < exp (3*(487/50)) := by
  have h : (1 + (487 / 50 : ℚ)^2)^7/16 < expTaylor (1461/50) 96 := by
    decide +kernel
  have cast : (1 + (487 / 50 : ℝ)^2)^7/16 < (expTaylor (1461/50) 96 : ℝ) := by
    simpa using (Rat.cast_lt (K := ℝ)).mpr h
  rw [show (3 : ℝ)*(487/50) = 1461/50 by norm_num]
  exact cast.trans_le (by simpa using expTaylor_le_exp (q := 1461/50) (by norm_num) 96)

theorem seventh_power {n : ℕ} (hn : 96 ≤ n) {x : ℝ}
    (outer : 3*sqrt ((n-1 : ℕ) : ℝ) ≤ x) :
    exp (-x)*(n:ℝ)^7 < 16 := by
  let t := sqrt ((n-1 : ℕ) : ℝ)
  have ht0 : 0 ≤ t := sqrt_nonneg _
  have hsq : t^2 = ((n-1 : ℕ) : ℝ) := sq_sqrt (by positivity)
  have hsize : 1+t^2 = (n:ℝ) := by
    rw [hsq, Nat.cast_sub (by omega : 1 ≤ n)]
    push_cast
    ring
  have hn' : (96:ℝ) ≤ n := by exact_mod_cast hn
  have ht : (487/50:ℝ) ≤ t := by
    apply (sq_le_sq₀ (by norm_num) ht0).mp
    linarith only [hsize, hn']
  have comp := OuterDecayEnvelope.compare (by norm_num : (0:ℝ) < 487/50)
    ht 7 (c := 3) (by norm_num)
  have anchor : (1+(487/50:ℝ)^2)^7 * exp (-(3*(487/50))) < 16 := by
    rw [exp_neg, ← div_eq_mul_inv, div_lt_iff₀ (exp_pos _)]
    exact (div_lt_iff₀ (by norm_num : (0:ℝ) < 16)).mp anchor_exp |>.trans_eq (by ring)
  calc
    exp (-x)*(n:ℝ)^7 ≤ exp (-(3*t))*(n:ℝ)^7 :=
      mul_le_mul_of_nonneg_right (exp_le_exp.mpr (neg_le_neg outer)) (by positivity)
    _ = (1+t^2)^7*exp (-(3*t)) := by rw [hsize, mul_comm]
    _ ≤ _ := comp
    _ < 16 := anchor

theorem reserve {n : ℕ} (hn : 96 ≤ n) : 6*(n:ℝ)^7 ≤ (2:ℝ)^(n-7) := by
  induction n, hn using Nat.le_induction with
  | base => norm_num
  | succ n hn ih =>
    have hn' : (96:ℝ) ≤ n := by exact_mod_cast hn
    have growth : (n:ℝ)+1 ≤ (21/20)*(n:ℝ) := by linarith
    have step := pow_le_pow_left₀ (by positivity) growth 7
    rw [mul_pow] at step
    rw [show n+1-7 = (n-7)+1 by omega, pow_succ (2:ℝ) (n-7), Nat.cast_succ]
    nlinarith only [step, ih, pow_nonneg (Nat.cast_nonneg (α := ℝ) n) 7]

#print axioms seventh_power
#print axioms reserve
end LongCycleBounds.SevenCutoff.Exterior
