import LongCycleBounds.SevenCompactResidue
import LongCycleFinite.K7CompactCert.Verified

noncomputable section
namespace LongCycleBounds.SevenCutoff
open Real FixedCutoff PoleBridge LongCycleFinite.K7CompactCert

theorem compact_sign {w : ℕ → ℝ} (w1 : w 1=0) (tail : ∀ a ≥ 7, w a=1)
    (unit : ∀ i, w i ∈ Set.Icc (0:ℝ) 1) {x : ℝ} (hx : 0 ≤ x) (xmax : x ≤ 16)
    {p : ℕ} (hp : 95 ≤ p) (zero : CycleProfile.normalizedRow w p x=0) :
    0 < CycleProfile.normalizedRow w (p+1) x * (-deriv (CycleProfile.normalizedRow w p) x) := by
  obtain ⟨c,mem,hc,xa,xb⟩ := covers hx xmax
  obtain ⟨_,_,hr,hthird⟩ := cell_radii hc.1 xa xb
  obtain ⟨rLo,rHi⟩ := Cell.r_bounds hc xa xb
  have inv := cell_inverse_amplitude hc xa xb w1 unit
  have error := residue_of_inverse_amplitude hc xa xb w1 unit inv
  have cap := cell_drift hc xa xb rLo rHi unit
  have d : (c.drift:ℝ) ≤ 24 := by exact_mod_cast (budget_caps mem).2.1.le
  apply scaled_gap_to_normalized_sign (by decide : 2≤7) (by omega : 7-1≤p) w w1 tail hx
    (radius_pos x) (CycleProfile.normalizedRow_insertion (by decide : 3≤7) (by omega) w w1 tail x)
  have hp' : (95:ℝ) ≤ p := by exact_mod_cast hp
  exact CompactCell.gap_of_cell (k:=7) (p:=p) (j₀:=89) (ε:=1/8) (K:=24)
    (by decide) (by omega) (by omega) (by norm_num) (by norm_num) (by linarith only [hp'])
    w1 tail hx hr hthird zero error (cap.trans (mul_le_mul_of_nonneg_right d
      (div_pos pi_pos (radius_pos x)).le))

#print axioms compact_sign
end LongCycleBounds.SevenCutoff
