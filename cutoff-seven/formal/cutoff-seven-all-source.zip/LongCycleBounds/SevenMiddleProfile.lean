import LongCycleBounds.SevenProfile
import LongCycleBounds.SevenMiddleScalars
import LongCycleBounds.SixMiddleBudgets

/-! Transfer the middle budgets to the actual short-cycle coefficients. -/
noncomputable section

namespace LongCycleBounds.SevenCutoff

open Real FixedCutoff Band PoleBridge MarkedTwo Finset Middle

theorem middle_b_nonneg {w : ℕ → ℝ} (one : w 1 = 0) (tail : ∀ a ≥ 7, w a = 1)
    (unit : ∀ i, w i ∈ Set.Icc (0:ℝ) 1) {x : ℝ} (hx : 16 ≤ x) (a : ℕ) (ha : 0 < a) :
    0 ≤ tiltCoefficient w a x := by
  by_cases large : 7 ≤ a
  · simp [tiltCoefficient, tail a large]
  by_cases sixth : a = 6
  · subst a
    have er := (exp_le_exp.mpr (show -x ≤ -16 by linarith)).trans exp_neg_sixteen
    have shape := FiveCutoff.shape_bounds (exp_pos (-x)).le
      (exp_le_one_iff.mpr (by linarith))
    have h := shape.2.1
    have h0 := shape.1
    rw [tiltCoefficient, SixCutoff.sixth_moment]
    apply div_nonneg _ (by positivity)
    apply mul_nonneg_of_nonpos_of_nonpos (sub_nonpos.mpr (unit 6).2)
    exact mul_nonpos_of_nonpos_of_nonneg (neg_nonpos.mpr h0)
      (by nlinarith only [h, er, sq_nonneg (FiveCutoff.height (exp (-x)))])
  let v : ℕ → ℝ := fun i ↦ if 6 ≤ i then 1 else w i
  have all : ∀ i, v i ∈ Set.Icc (0:ℝ) 1 := by
    intro i
    by_cases h : 6 ≤ i <;> simp [v, h, unit i]
  have bound := SixCutoff.middle_b_nonneg (w:=v) (by simpa [v] using one)
    (fun i h ↦ by simp [v, h]) all (by linarith : 13 ≤ x) a ha
  simpa [tiltCoefficient, v, show ¬6 ≤ a by omega] using bound

private theorem sextic_at_sixteen {R : ℝ} (hR : 16 ≤ R) :
    sextic R ≤ (100117/47185920:ℝ)*R^6 := by
  simpa only [show sextic 16/(16:ℝ)^6 = 100117/47185920 by
    norm_num [sextic, sum_range_succ, Nat.factorial]]
    using sextic_majorant (by norm_num : (0:ℝ) < 16) hR

theorem middle_profile_cost {w : ℕ → ℝ} (one : w 1 = 0)
    (unit : ∀ i, w i ∈ Set.Icc (0:ℝ) 1) {x R : ℝ} (hx : 0 ≤ x) (hR : 16 ≤ R) :
    cost (fun a ↦ tiltCoefficient w a x) R 6 ≤ (100117/47185920:ℝ)*exp (-x)*R^6 := by
  exact (profile_cost one unit hx (by linarith)).trans
    ((mul_le_mul_of_nonneg_left (sextic_at_sixteen hR) (exp_pos (-x)).le).trans_eq (by ring))

theorem middle_costs {w : ℕ → ℝ} (one : w 1 = 0) (unit : ∀ i, w i ∈ Set.Icc (0:ℝ) 1)
    {x : ℝ} (hx : 16 ≤ x) :
    let b := fun a ↦ tiltCoefficient w a x
    cost b (radius x) 6 ≤ (1/200:ℝ) ∧ exp (cost b (2*radius x) 6) < 2 := by
  dsimp only
  have rr : 16 ≤ radius x := hx.trans (FixedFour49.radius_bounds (by linarith : 9≤x)).1
  have x0 : 0 ≤ x := by linarith
  have decay := radius_power_decay hx (radius_pos x).le (radius_le_alpha hx) (m:=6) (by decide)
  have h := mul_le_mul_of_nonneg_left decay (by norm_num : (0:ℝ) ≤ 100117/47185920)
  have small : (100117/47185920:ℝ)*exp (-x)*(radius x)^6 ≤ 1/200 := by
    norm_num at h
    linarith only [h]
  refine ⟨(middle_profile_cost one unit x0 rr).trans small, ?_⟩
  let v := cost (fun a ↦ tiltCoefficient w a x) (2*radius x) 6
  have v0 : 0 ≤ v := sum_nonneg fun _ _ ↦ mul_nonneg (abs_nonneg _) (by positivity)
  have raw := middle_profile_cost one unit x0 (show 16 ≤ 2*radius x by linarith)
  have wide : v ≤ (64/200:ℝ) := by
    change v ≤ _ at raw
    rw [mul_pow] at raw
    linarith only [raw, small]
  have v1 : v < 1 := wide.trans_lt (by norm_num)
  apply (exp_bound_div_one_sub_of_interval v0 v1).trans_lt
  exact (div_lt_iff₀ (sub_pos.mpr v1)).mpr (by linarith only [wide])

/-- The common drift factor suffices with the middle-region allowance of one half. -/
theorem middle_drift_sum {w : ℕ → ℝ} (unit : ∀ i, w i ∈ Set.Icc (0:ℝ) 1)
    {x : ℝ} (hx : 16 ≤ x) :
    (∑ i ∈ range 6, |drift w (i+1) x| *(radius x)^(i+2)) ≤ (1/2:ℝ)*s x := by
  let R := radius x
  let r := exp (-x)
  have rp : 0 < R := radius_pos x
  have rr : 16 ≤ R := hx.trans (FixedFour49.radius_bounds (by linarith : 9≤x)).1
  have r0 : 0 ≤ r := (exp_pos _).le
  have scale : (∑ i ∈ range 6, |drift w (i+1) x| * R^(i+2)) ≤
      ((21/20)*r*sextic R)*R := by
    unfold sextic
    rw [mul_sum, sum_mul]
    apply sum_le_sum
    intro i hi
    have ib := mem_range.mp hi
    rw [show i+2 = i+1+1 by omega, pow_succ]
    exact (mul_le_mul_of_nonneg_right
      (drift_factorial unit (by linarith : 0 ≤ x) (by omega) (by omega))
      (by positivity : 0 ≤ R^(i+1)*R)).trans_eq (by ring)
  have sext := mul_le_mul_of_nonneg_right
    (mul_le_mul_of_nonneg_left (sextic_at_sixteen rr)
      (by positivity : 0 ≤ (21/20:ℝ)*r)) (sq_nonneg R)
  have big := mul_le_mul_of_nonneg_right scale rp.le
  have decay := radius_power_decay hx rp.le (radius_le_alpha hx) (m:=8) (by decide)
  have tight := mul_le_mul_of_nonneg_left decay
    (by norm_num : (0:ℝ) ≤ (21/20)*(100117/47185920))
  norm_num at tight
  change _ ≤ (1/2:ℝ)*(π/R)
  rw [←mul_div_assoc, le_div_iff₀ rp]
  linarith only [big, sext, tight, pi_gt_d6]

theorem middle_half_order (x : ℝ) (hx : 0 ≤ x) {n j i : ℕ} (hn : 96 ≤ n)
    (hj : n-7 ≤ j) (hi : i ≤ j/2) :
    |scaledCoeff (logistic (time x)) (radius x) (j-i)| ≤
      2 + 2*(radius x)^2/(((n-5:ℕ):ℝ)*π^2) := by
  simpa only [Nat.sub_sub] using FixedFour49.logistic_half_order_bound x hx
    (n:=n-3) (j:=j) (i:=i) (by omega) (by omega) hi

theorem middle_short_row {n j : ℕ} (hn : 96 ≤ n) (hj : n-7 ≤ j) {x : ℝ} (hx : 0 ≤ x)
    (angle : 1 ≤ (n:ℝ)*(s x)^2) :
    |scaledCoeff (logistic (time x)) (radius x) j| ≤ 2+(n:ℝ)/((n-6:ℕ):ℝ) := by
  have sp : 0 < s x := div_pos pi_pos (radius_pos x)
  have orders : ((n-6:ℕ):ℝ) ≤ (j+1:ℕ) := by exact_mod_cast (show n-6 ≤ j+1 by omega)
  have dest := mul_le_mul_of_nonneg_right orders (sq_nonneg (s x))
  have nn : (0:ℝ) ≤ n := Nat.cast_nonneg n
  have d : (0:ℝ) < ((n-6:ℕ):ℝ) := by exact_mod_cast (show 0<n-6 by omega)
  have den : 0 < ((j+1:ℕ):ℝ)*(s x)^2 := by positivity
  apply (FixedFour49.logistic_ordered_bound x hx (by omega : 1≤j)).trans
  apply add_le_add (le_refl 2)
  rw [div_le_div_iff₀ den d, one_mul]
  have t := mul_le_mul_of_nonneg_right angle d.le
  nlinarith only [t, mul_le_mul_of_nonneg_left dest nn]

#print axioms middle_b_nonneg
#print axioms middle_costs
#print axioms middle_drift_sum
#print axioms middle_half_order
#print axioms middle_short_row
end LongCycleBounds.SevenCutoff
