# Correspondence to Alexandersson’s long-cycle conjecture

The source is the section [Permutations with long cycles](https://www.symmetricfunctions.com/realRootedOpenProblems.htm#permutations-with-long-cycles). Fix k=7 and use n for the upper of the two sizes. Every nonempty pair has n≥8. The statistic counts positions i with i<σ(i). The ordering includes every zero with its multiplicity.

* LongCycleFinite.K7Prefix.OriginalPair unfolds to the two original enumerators factored by X, strict negative interlacing of their quotients, and weak interlacing of the full rows.
* LongCycleFinite.K7Prefix.finite_original proves this predicate from 8 through 95 by kernel-checked signs at negative dyadic isolating intervals, with the coefficients linked to the permutation rows.
* LongCycleBounds.SevenCutoff.independent_weights quantifies over every fixed profile valued in [0,1], with w₁=0 and all weights from length seven equal to one. It covers both quotient and original rows at all upper sizes n≥96. The same weights are used in the two rows. The specialization with all five short weights zero is LongCycleBounds.SevenCutoff.original.
* LongCycleBounds.SevenCutoff.all_sizes joins the adjacent finite and infinite ranges for the hard cutoff. The conjecture at unrestricted k and the five-dimensional weight cube below 96 are outside this theorem.
