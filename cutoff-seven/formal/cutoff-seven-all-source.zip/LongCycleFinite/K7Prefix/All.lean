import LongCycleFinite.K7Prefix.Rows95

namespace LongCycleFinite.K7Prefix

set_option maxRecDepth 16384
set_option maxHeartbeats 4000000

/-- All original adjacent cutoff-seven pairs with upper size from eight through 95. -/
theorem finite_original {n : ℕ} (lo : 8 ≤ n) (hi : n ≤ 95) : OriginalPair n := by
  interval_cases n
  · exact pair8
  · exact pair9
  · exact pair10
  · exact pair11
  · exact pair12
  · exact pair13
  · exact pair14
  · exact pair15
  · exact pair16
  · exact pair17
  · exact pair18
  · exact pair19
  · exact pair20
  · exact pair21
  · exact pair22
  · exact pair23
  · exact pair24
  · exact pair25
  · exact pair26
  · exact pair27
  · exact pair28
  · exact pair29
  · exact pair30
  · exact pair31
  · exact pair32
  · exact pair33
  · exact pair34
  · exact pair35
  · exact pair36
  · exact pair37
  · exact pair38
  · exact pair39
  · exact pair40
  · exact pair41
  · exact pair42
  · exact pair43
  · exact pair44
  · exact pair45
  · exact pair46
  · exact pair47
  · exact pair48
  · exact pair49
  · exact pair50
  · exact pair51
  · exact pair52
  · exact pair53
  · exact pair54
  · exact pair55
  · exact pair56
  · exact pair57
  · exact pair58
  · exact pair59
  · exact pair60
  · exact pair61
  · exact pair62
  · exact pair63
  · exact pair64
  · exact pair65
  · exact pair66
  · exact pair67
  · exact pair68
  · exact pair69
  · exact pair70
  · exact pair71
  · exact pair72
  · exact pair73
  · exact pair74
  · exact pair75
  · exact pair76
  · exact pair77
  · exact pair78
  · exact pair79
  · exact pair80
  · exact pair81
  · exact pair82
  · exact pair83
  · exact pair84
  · exact pair85
  · exact pair86
  · exact pair87
  · exact pair88
  · exact pair89
  · exact pair90
  · exact pair91
  · exact pair92
  · exact pair93
  · exact pair94
  · exact pair95

#print axioms finite_original

end LongCycleFinite.K7Prefix
