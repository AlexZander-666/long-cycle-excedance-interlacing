import LongCycleFinite.K7Prefix.Rows15

namespace LongCycleFinite.K7Prefix
open LongCycleBounds.CycleProfile.Counterexample
set_option maxRecDepth 16384
set_option maxHeartbeats 4000000

def p16 : List ℤ :=
  [1, 50627, 18846899, 1169713642, 20746574881, 141700848893, 429449977131, 617069415852,
   429449977131, 141700848893, 20746574881, 1169713642, 18846899, 50627, 1]
def t16 : List (List ℤ) := (0 :: p16) :: t15
theorem h16 : coefficientTable weights 16 = t16 :=
  table_step h15 (by decide +kernel)
theorem row16 : LongCycles.enumerator 16 7 = Polynomial.X * ofCoeffs p16 :=
  row_from_table (past := t15) h16
def w16 : List Window := [⟨⟨-22784, 0⟩, ⟨-22272, 0⟩⟩,
   ⟨⟨-202, 0⟩, ⟨-198, 0⟩⟩,
   ⟨⟨-71, 1⟩, ⟨-69, 1⟩⟩,
   ⟨⟨-77, 3⟩, ⟨-75, 3⟩⟩,
   ⟨⟨-67, 4⟩, ⟨-65, 4⟩⟩,
   ⟨⟨-125, 6⟩, ⟨-123, 6⟩⟩,
   ⟨⟨-65, 6⟩, ⟨-127, 7⟩⟩,
   ⟨⟨-67, 7⟩, ⟨-65, 7⟩⟩,
   ⟨⟨-125, 9⟩, ⟨-123, 9⟩⟩,
   ⟨⟨-109, 10⟩, ⟨-107, 10⟩⟩,
   ⟨⟨-117, 12⟩, ⟨-115, 12⟩⟩,
   ⟨⟨-83, 14⟩, ⟨-81, 14⟩⟩,
   ⟨⟨-93, 21⟩, ⟨-91, 21⟩⟩]
theorem checked16 : caseOK p15 p16 ⟨-1257747079913946359297510211584, 0⟩ w16 = true := by
  decide +kernel
theorem pair16 : OriginalPair 16 :=
  original_of_window row15 row16 (by decide) (by decide) checked16

def p17 : List ℤ :=
  [1, 109277, 61725947, 5272404447, 126360388477, 1156485847489, 4744102656551, 9439787882211,
   9439787882211, 4744102656551, 1156485847489, 126360388477, 5272404447, 61725947, 109277, 1]
def t17 : List (List ℤ) := (0 :: p17) :: t16
theorem h17 : coefficientTable weights 17 = t17 :=
  table_step h16 (by decide +kernel)
theorem row17 : LongCycles.enumerator 17 7 = Polynomial.X * ofCoeffs p17 :=
  row_from_table (past := t16) h17
def w17 : List Window := [⟨⟨-50688, 0⟩, ⟨-49664, 0⟩⟩,
   ⟨⟨-308, 0⟩, ⟨-300, 0⟩⟩,
   ⟨⟨-99, 1⟩, ⟨-97, 1⟩⟩,
   ⟨⟨-105, 3⟩, ⟨-103, 3⟩⟩,
   ⟨⟨-87, 4⟩, ⟨-85, 4⟩⟩,
   ⟨⟨-85, 5⟩, ⟨-83, 5⟩⟩,
   ⟨⟨-87, 6⟩, ⟨-85, 6⟩⟩,
   ⟨⟨-97, 7⟩, ⟨-95, 7⟩⟩,
   ⟨⟨-99, 8⟩, ⟨-97, 8⟩⟩,
   ⟨⟨-97, 9⟩, ⟨-95, 9⟩⟩,
   ⟨⟨-81, 10⟩, ⟨-79, 10⟩⟩,
   ⟨⟨-85, 12⟩, ⟨-83, 12⟩⟩,
   ⟨⟨-109, 15⟩, ⟨-107, 15⟩⟩,
   ⟨⟨-85, 22⟩, ⟨-83, 22⟩⟩]
theorem checked17 : caseOK p16 p17 ⟨-1257747079913946359297510211584, 0⟩ w17 = true := by
  decide +kernel
theorem pair17 : OriginalPair 17 :=
  original_of_window row16 row17 (by decide) (by decide) checked17

def p18 : List ℤ :=
  [1, 230946, 200059316, 23264189054, 743514400996, 8975155023994, 48751468374924,
   130521909109478, 180354612448182, 130521909109478, 48751468374924, 8975155023994, 743514400996,
   23264189054, 200059316, 230946, 1]
def t18 : List (List ℤ) := (0 :: p18) :: t17
theorem h18 : coefficientTable weights 18 = t18 :=
  table_step h17 (by decide +kernel)
theorem row18 : LongCycles.enumerator 18 7 = Polynomial.X * ofCoeffs p18 :=
  row_from_table (past := t17) h18
def w18 : List Window := [⟨⟨-109568, 0⟩, ⟨-107520, 0⟩⟩,
   ⟨⟨-476, 0⟩, ⟨-468, 0⟩⟩,
   ⟨⟨-67, 0⟩, ⟨-65, 0⟩⟩,
   ⟨⟨-71, 2⟩, ⟨-69, 2⟩⟩,
   ⟨⟨-111, 4⟩, ⟨-109, 4⟩⟩,
   ⟨⟨-111, 5⟩, ⟨-109, 5⟩⟩,
   ⟨⟨-115, 6⟩, ⟨-113, 6⟩⟩,
   ⟨⟨-65, 6⟩, ⟨-127, 7⟩⟩,
   ⟨⟨-73, 7⟩, ⟨-71, 7⟩⟩,
   ⟨⟨-75, 8⟩, ⟨-73, 8⟩⟩,
   ⟨⟨-75, 9⟩, ⟨-73, 9⟩⟩,
   ⟨⟨-117, 11⟩, ⟨-115, 11⟩⟩,
   ⟨⟨-125, 13⟩, ⟨-123, 13⟩⟩,
   ⟨⟨-71, 15⟩, ⟨-69, 15⟩⟩,
   ⟨⟨-79, 23⟩, ⟨-77, 23⟩⟩]
theorem checked18 : caseOK p17 p18 ⟨-1257747079913946359297510211584, 0⟩ w18 = true := by
  decide +kernel
theorem pair18 : OriginalPair 18 :=
  original_of_window row17 row18 (by decide) (by decide) checked18

def p19 : List ℤ :=
  [1, 480473, 642727536, 101051194880, 4257108829380, 66896160754324, 472769773672032,
   1664370872911024, 3083840677532750, 3083840677532750, 1664370872911024, 472769773672032,
   66896160754324, 4257108829380, 101051194880, 642727536, 480473, 1]
def t19 : List (List ℤ) := (0 :: p19) :: t18
theorem h19 : coefficientTable weights 19 = t19 :=
  table_step h18 (by decide +kernel)
theorem row19 : LongCycles.enumerator 19 7 = Polynomial.X * ofCoeffs p19 :=
  row_from_table (past := t18) h19
def w19 : List Window := [⟨⟨-231424, 0⟩, ⟨-227328, 0⟩⟩,
   ⟨⟨-744, 0⟩, ⟨-728, 0⟩⟩,
   ⟨⟨-89, 0⟩, ⟨-87, 0⟩⟩,
   ⟨⟨-97, 2⟩, ⟨-95, 2⟩⟩,
   ⟨⟨-71, 3⟩, ⟨-69, 3⟩⟩,
   ⟨⟨-71, 4⟩, ⟨-69, 4⟩⟩,
   ⟨⟨-75, 5⟩, ⟨-73, 5⟩⟩,
   ⟨⟨-85, 6⟩, ⟨-83, 6⟩⟩,
   ⟨⟨-99, 7⟩, ⟨-97, 7⟩⟩,
   ⟨⟨-111, 8⟩, ⟨-109, 8⟩⟩,
   ⟨⟨-119, 9⟩, ⟨-117, 9⟩⟩,
   ⟨⟨-117, 10⟩, ⟨-115, 10⟩⟩,
   ⟨⟨-87, 11⟩, ⟨-85, 11⟩⟩,
   ⟨⟨-93, 13⟩, ⟨-91, 13⟩⟩,
   ⟨⟨-89, 16⟩, ⟨-87, 16⟩⟩,
   ⟨⟨-73, 24⟩, ⟨-71, 24⟩⟩]
theorem checked19 : caseOK p18 p19 ⟨-1257747079913946359297510211584, 0⟩ w19 = true := by
  decide +kernel
theorem pair19 : OriginalPair 19 :=
  original_of_window row18 row19 (by decide) (by decide) checked19

end LongCycleFinite.K7Prefix
