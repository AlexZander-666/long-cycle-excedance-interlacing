import LongCycleFinite.K7Prefix.Rows03

namespace LongCycleFinite.K7Prefix
open LongCycleBounds.CycleProfile.Counterexample
set_option maxRecDepth 16384
set_option maxHeartbeats 4000000

def t4 : List (List ℤ) := [0, 0, 0, 0] :: t3
theorem h4 : coefficientTable weights 4 = t4 :=
  table_step h3 (by decide +kernel)

def t5 : List (List ℤ) := [0, 0, 0, 0, 0] :: t4
theorem h5 : coefficientTable weights 5 = t5 :=
  table_step h4 (by decide +kernel)

def t6 : List (List ℤ) := [0, 0, 0, 0, 0, 0] :: t5
theorem h6 : coefficientTable weights 6 = t6 :=
  table_step h5 (by decide +kernel)

def p7 : List ℤ :=
  [1, 57, 302, 302, 57, 1]
def t7 : List (List ℤ) := (0 :: p7) :: t6
theorem h7 : coefficientTable weights 7 = t7 :=
  table_step h6 (by decide +kernel)
theorem row7 : LongCycles.enumerator 7 7 = Polynomial.X * ofCoeffs p7 :=
  row_from_table (past := t6) h7

end LongCycleFinite.K7Prefix
