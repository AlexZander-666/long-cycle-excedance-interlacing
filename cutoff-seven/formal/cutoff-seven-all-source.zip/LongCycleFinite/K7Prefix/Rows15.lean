import LongCycleFinite.K7Prefix.Rows11

namespace LongCycleFinite.K7Prefix
open LongCycleBounds.CycleProfile.Counterexample
set_option maxRecDepth 16384
set_option maxHeartbeats 4000000

def p12 : List ℤ :=
  [1, 2036, 152637, 2203488, 9738114, 15724248, 9738114, 2203488, 152637, 2036, 1]
def t12 : List (List ℤ) := (0 :: p12) :: t11
theorem h12 : coefficientTable weights 12 = t12 :=
  table_step h11 (by decide +kernel)
theorem row12 : LongCycles.enumerator 12 7 = Polynomial.X * ofCoeffs p12 :=
  row_from_table (past := t11) h12
def w12 : List Window := [⟨⟨-968, 0⟩, ⟨-952, 0⟩⟩,
   ⟨⟨-77, 1⟩, ⟨-75, 1⟩⟩,
   ⟨⟨-121, 4⟩, ⟨-119, 4⟩⟩,
   ⟨⟨-81, 5⟩, ⟨-79, 5⟩⟩,
   ⟨⟨-65, 6⟩, ⟨-127, 7⟩⟩,
   ⟨⟨-103, 8⟩, ⟨-101, 8⟩⟩,
   ⟨⟨-69, 9⟩, ⟨-67, 9⟩⟩,
   ⟨⟨-111, 12⟩, ⟨-109, 12⟩⟩,
   ⟨⟨-69, 16⟩, ⟨-67, 16⟩⟩]
theorem checked12 : caseOK p11 p12 ⟨-1257747079913946359297510211584, 0⟩ w12 = true := by
  decide +kernel
theorem pair12 : OriginalPair 12 :=
  original_of_window row11 row12 (by decide) (by decide) checked12

def p13 : List ℤ :=
  [1, 4083, 478271, 10187685, 66318474, 162512286, 162512286, 66318474, 10187685, 478271, 4083, 1]
def t13 : List (List ℤ) := (0 :: p13) :: t12
theorem h13 : coefficientTable weights 13 = t13 :=
  table_step h12 (by decide +kernel)
theorem row13 : LongCycles.enumerator 13 7 = Polynomial.X * ofCoeffs p13 :=
  row_from_table (past := t12) h13
def w13 : List Window := [⟨⟨-1968, 0⟩, ⟨-1936, 0⟩⟩,
   ⟨⟨-121, 1⟩, ⟨-119, 1⟩⟩,
   ⟨⟨-91, 3⟩, ⟨-89, 3⟩⟩,
   ⟨⟨-119, 5⟩, ⟨-117, 5⟩⟩,
   ⟨⟨-97, 6⟩, ⟨-95, 6⟩⟩,
   ⟨⟨-85, 7⟩, ⟨-83, 7⟩⟩,
   ⟨⟨-71, 8⟩, ⟨-69, 8⟩⟩,
   ⟨⟨-93, 10⟩, ⟨-91, 10⟩⟩,
   ⟨⟨-69, 12⟩, ⟨-67, 12⟩⟩,
   ⟨⟨-67, 17⟩, ⟨-65, 17⟩⟩]
theorem checked13 : caseOK p12 p13 ⟨-1257747079913946359297510211584, 0⟩ w13 = true := by
  decide +kernel
theorem pair13 : OriginalPair 13 :=
  original_of_window row12 row13 (by decide) (by decide) checked13

def p14 : List ℤ :=
  [1, 9894, 1675350, 52145198, 483396447, 1721401644, 2599338132, 1721401644, 483396447, 52145198,
   1675350, 9894, 1]
def t14 : List (List ℤ) := (0 :: p14) :: t13
theorem h14 : coefficientTable weights 14 = t14 :=
  table_step h13 (by decide +kernel)
theorem row14 : LongCycles.enumerator 14 7 = Polynomial.X * ofCoeffs p14 :=
  row_from_table (past := t13) h14
def w14 : List Window := [⟨⟨-4000, 0⟩, ⟨-3936, 0⟩⟩,
   ⟨⟨-95, 0⟩, ⟨-93, 0⟩⟩,
   ⟨⟨-65, 2⟩, ⟨-127, 3⟩⟩,
   ⟨⟨-85, 4⟩, ⟨-83, 4⟩⟩,
   ⟨⟨-71, 5⟩, ⟨-69, 5⟩⟩,
   ⟨⟨-65, 6⟩, ⟨-127, 7⟩⟩,
   ⟨⟨-119, 8⟩, ⟨-117, 8⟩⟩,
   ⟨⟨-99, 9⟩, ⟨-97, 9⟩⟩,
   ⟨⟨-127, 11⟩, ⟨-125, 11⟩⟩,
   ⟨⟨-87, 13⟩, ⟨-85, 13⟩⟩,
   ⟨⟨-67, 18⟩, ⟨-65, 18⟩⟩]
theorem checked14 : caseOK p13 p14 ⟨-1257747079913946359297510211584, 0⟩ w14 = true := by
  decide +kernel
theorem pair14 : OriginalPair 14 :=
  original_of_window row13 row14 (by decide) (by decide) checked14

def p15 : List ℤ :=
  [1, 22804, 5676309, 252033641, 3259289750, 16285228533, 35462558562, 35462558562, 16285228533,
   3259289750, 252033641, 5676309, 22804, 1]
def t15 : List (List ℤ) := (0 :: p15) :: t14
theorem h15 : coefficientTable weights 15 = t15 :=
  table_step h14 (by decide +kernel)
theorem row15 : LongCycles.enumerator 15 7 = Polynomial.X * ofCoeffs p15 :=
  row_from_table (past := t14) h15
def w15 : List Window := [⟨⟨-9856, 0⟩, ⟨-9600, 0⟩⟩,
   ⟨⟨-138, 0⟩, ⟨-134, 0⟩⟩,
   ⟨⟨-99, 2⟩, ⟨-97, 2⟩⟩,
   ⟨⟨-111, 4⟩, ⟨-109, 4⟩⟩,
   ⟨⟨-101, 5⟩, ⟨-99, 5⟩⟩,
   ⟨⟨-89, 6⟩, ⟨-87, 6⟩⟩,
   ⟨⟨-93, 7⟩, ⟨-91, 7⟩⟩,
   ⟨⟨-83, 8⟩, ⟨-81, 8⟩⟩,
   ⟨⟨-75, 9⟩, ⟨-73, 9⟩⟩,
   ⟨⟨-85, 11⟩, ⟨-83, 11⟩⟩,
   ⟨⟨-123, 14⟩, ⟨-121, 14⟩⟩,
   ⟨⟨-109, 20⟩, ⟨-107, 20⟩⟩]
theorem checked15 : caseOK p14 p15 ⟨-1257747079913946359297510211584, 0⟩ w15 = true := by
  decide +kernel
theorem pair15 : OriginalPair 15 :=
  original_of_window row14 row15 (by decide) (by decide) checked15

end LongCycleFinite.K7Prefix
