import LongCycleFinite.K5CompactCert.Checks

/-! # Exact endpoint constants for the cutoff-six middle region -/

namespace LongCycleFinite.K6MiddleCert

open K5CompactCert

/-- The rounded bound for the ratio of the pole radius to x, at x ≥ 13. -/
def alpha : ℚ := 10287859 / 10000000

/-- The rounded upper bound on the exponential at −13. -/
def r0 : ℚ := 23 / 10000000

/-- The majorant of the four exponential tilt coefficients at radius at least 13. -/
def C : ℚ := 1 / 13^4 + 1 / (2*13^3) + 1 / (6*13^2) + 1 / (24*13) + 1 / 120

def vFormula : ℚ := C * alpha ^ 5 * 13 ^ 5 * r0

/-- Upper bound for the tilt cost at the physical radius. -/
def v0 : ℚ := roundUp vFormula

def headFormula : ℚ :=
  C * r0 * (2 * alpha ^ 6 * 13 ^ 6 + 2 * alpha ^ 8 * 13 ^ 8 / (45 * piLo ^ 2)) /
    (piLo * (1 - v0))

/-- Rounded head budget after division by the sine. -/
def head : ℚ := roundUp headFormula

def tailAt (n : ℕ) : ℚ := 14 * n / 2 ^ ((n - 6) / 2)

/-- Rounded tail budget, with both starting parities. -/
def tail : ℚ := roundUp (max (tailAt 49) (tailAt 50))

def driftFormula : ℚ := C * r0 * alpha ^ 7 * 13 ^ 7 / piLo

/-- Rounded insertion drift after division by the sine. -/
def J : ℚ := roundUp driftFormula

theorem endpoint_arithmetic :
    0 < alpha ∧ 1 + (piHi / 13) ^ 2 ≤ alpha ^ 2 ∧
      0 < r0 ∧ 1 ≤ r0 * expTaylor 13 64 := by decide +kernel

theorem rounded_values :
    C = 21913 / 1713660 ∧ v0 = 125849 / 10000000 ∧ head = 761103 / 5000000 ∧
      tail = 409 / 1250000 ∧ J = 3582647 / 5000000 := by decide +kernel

theorem main_arithmetic :
    0 < v0 ∧ v0 < 8877 / 500000 ∧ head < 17 / 100 ∧ head + tail < 1 / 4 ∧
      0 < J ∧ J < 1 := by decide +kernel

theorem exponential_arithmetic :
    smallArgument (32 * v0) 1 ≤ 1 / 4 ∧
      expUpper (32 * v0) 1 = 7479417 / 5000000 ∧ expUpper (32 * v0) 1 < 2 := by
  decide +kernel

theorem reserve_arithmetic :
    18 * alpha ^ 3 / piLo < 7 ∧ 2 + (49 / 44 : ℚ) + 1 / 4 < 4 ∧ 4 * J / 49 < 1 / 2 := by
  decide +kernel

end LongCycleFinite.K6MiddleCert
