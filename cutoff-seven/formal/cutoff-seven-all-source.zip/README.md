# Strict-excedance interlacing at minimum cycle length seven

For each n ≥ 8, the strict-excedance polynomials of permutations at sizes n−1 and n with all cycles of length at least seven have one common simple zero at zero. Dividing by the variable gives simple negative zeros in strict interlacing order. At upper sizes n ≥ 96, the same conclusions hold with a common profile of five independent short-cycle weights.

The frozen package contains the exact Lean import closure, its eleven-declaration axiom audit, the toolchain and package revision locks, and a verifier. Extract the source ZIP, install the pinned Lean toolchain, and run `python3 verify_lean.py . SevenCutoffAudit`. Optionally pass `--packages /path/to/locked/.lake/packages` to reuse verified external dependencies. The verifier starts without compiled project objects. Its terminal PASS line records the number of independent kernel replays and transitive axiom reports. A source archive alone does not record a successful build.
