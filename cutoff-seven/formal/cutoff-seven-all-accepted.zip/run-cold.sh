#!/usr/bin/env bash
set -euo pipefail
release="$(cd "$(dirname "$0")" && pwd)"
dependencies="${1:?supply the locked third-party .lake/packages directory}"
export PATH="$HOME/.elan/bin:$PATH"
export LEAN_NUM_THREADS=1
ulimit -n 65536
python3 -Bu - "$release" "$dependencies" <<'PY'
from hashlib import sha256
from pathlib import Path
from tempfile import TemporaryDirectory
import subprocess
import sys
from zipfile import ZipFile

release = Path(sys.argv[1]).resolve(strict=True)
dependencies = Path(sys.argv[2]).resolve(strict=True)
archive = release / "cutoff-seven-all-source.zip"
print("source_zip_sha256", sha256(archive.read_bytes()).hexdigest())
with TemporaryDirectory(prefix="cutoff-seven-all-source-") as directory:
    project = Path(directory)
    with ZipFile(archive) as bundle:
        for name in bundle.namelist():
            path = Path(name)
            if path.is_absolute() or ".." in path.parts:
                raise SystemExit(f"Unexpected member path {name}")
        bundle.extractall(project)
    subprocess.run(["sha256sum", "-c", "SHA256SUMS", "--quiet"], cwd=project, check=True)
    print("source_manifest_check_exit=0")
    status = subprocess.run(
        [sys.executable, "-Bu", "verify_lean.py", ".", "SevenCutoffAudit",
         "--jobs", "4", "--packages", str(dependencies)], cwd=project,
    ).returncode
    print(f"source_cold_verifier_exit={status}")
    raise SystemExit(status)
PY
