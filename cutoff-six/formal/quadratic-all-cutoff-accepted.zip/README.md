# An explicit quadratic threshold for all cutoffs

Let n be the upper size in the adjacent pair (n−1,n), with the same cutoff k≥3 in both rows. For every n≥1,000,000(k−1)², the strict-excedance enumerators for permutations with every cycle of length at least k have strictly interlacing simple negative roots after dividing both rows by t. The actual rows weakly interlace, sharing a zero at t=0. The same conclusion holds throughout the closed cube of independent cycle weights at lengths 2 through k−1, with singleton weight zero and unit weight at all lengths at least k.

The top-level theorems are `LongCycleBounds.QuadraticCutoff.original` and `LongCycleBounds.QuadraticCutoff.independent_weights`. See [the statement map](STATEMENT-MAP.md) for the original permutation definition, sign regions, and reconstruction of the complete root lists. The threshold is a statement about the upper size n. Each cutoff has a finite prefix below this threshold, which this archive does not claim uniformly.

## Rebuild and replay

Use elan, Git, Python 3, and the pinned Lean v4.33.1 toolchain. The audit rebuilds all project modules in a fresh temporary directory, checks the pinned dependency checkouts and transitive axioms, and launches an independent replay for each original project module. It treats Lean warnings as failures. For a prebuilt third-party package cache, append `--packages /path/to/.lake/packages`.

```sh
sha256sum -c SHA256SUMS
LEAN_NUM_THREADS=1 python3 -Bu verify_lean.py . QuadraticCutoffAudit --jobs 4
```
