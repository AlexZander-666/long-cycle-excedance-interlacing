# Correspondence to the adjacent long-cycle excedance rows

**Original combinatorial input.** In [LongCycles.Statement](LongCycles/Statement.lean), `Allowed k σ` is the lower bound k on cycle lengths of the permutation σ of `Fin n`. The strict-excedance statistic counts positions with σ(i)>i. `enumerator n k` sums t raised to that statistic over allowed permutations. The two rows use the same cutoff. [The weighted row](LongCycleBounds/CycleProfile.lean) is the sum over derangements with multiplicative weights by cycle length. Its `row_zero` theorem recovers `enumerator n k` when short cycles have weight zero. [Weighted quotients and endpoint specialization](LongCycleBounds/CycleProfileIndependentWeights.lean)

**Actual conclusion.** In [QuadraticCutoffVerified.lean](LongCycleBounds/QuadraticCutoffVerified.lean), `LongCycleBounds.QuadraticCutoff.original` and `independent_weights` assume k≥3 and upper size n≥1,000,000(k−1)². The lower and upper quotient degrees are n−3 and n−2. Their exact real root multisets consist of the respective strictly alternating negative lists. The full rows weakly interlace after reinstating t=0. The admissible independent weights are all in [0,1], with w(1)=0 and w(a)=1 for a≥k. This threshold is uniform over all these weights for every allowed k. [Strict quotient definition](LongCycleFinite/Interlacing.lean) · [Weak interlacing definition](LongCycles/Statement.lean)

**Sign comparison.** `normalized_sign` uses p=n−1 and t=−exp(−x), with x≥0. A normalized row is the actual polynomial evaluated at t and divided by (1−t)^p. At every genuine predecessor zero the sign of the successor times the negative x-derivative of the predecessor is strictly positive. The proofs apply with a single fixed weight profile for both rows.

| Coverage | Declaration |
| --- | --- |
| 0≤x≤12(k−1)+100, with upper size p+1≥1,000,000(k−1)² | [`QuadraticCutoff.original_compact_sign`](LongCycleBounds/QuadraticCompactVerified.lean) |
| 12(k−1)+100≤x≤3√p | [`QuadraticCutoff.independent_effective_middle_sign`](LongCycleBounds/QuadraticMiddleVerified.lean) |
| 3√p≤x, p≥65,536 and p≥4k² | [`Occupancy.independent_quadratic_exterior_sign`](LongCycleBounds/QuadraticExteriorVerified.lean) |

The top-level size bound implies both exterior floors. The proof uses the first split at the compact endpoint, then the split at 3√p; shared endpoints satisfy the weak inequalities shown in the table. [Analytic coordinate and normalization](LongCycleBounds/CycleProfileNormalization.lean)

**Root readout.** `CycleProfile.independent_interlacing_of_normalized_sign` uses the normalized signs for admissible weights, strict-excedance symmetry, the all-long-cycle anchor and deformation within the cube to produce the root lists. The theorem covers x=0, both sides of the reciprocal center, and the original factor t. [Root proof](LongCycleBounds/CycleProfileIndependentReadout.lean) · [Audit and full Lean type output](QuadraticCutoffAudit.lean)
