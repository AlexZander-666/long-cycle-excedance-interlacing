# Cutoff-six formal statement map

| Claim | Declaration |
| --- | --- |
| Original strict quotient and weak original rows, every upper n≥7 | [`SixCutoff.all_sizes`](LongCycleBounds/SixCutoffVerified.lean) |
| Same for independent weights at every upper n≥49 | [`SixCutoff.independent_weights`](LongCycleBounds/SixCutoffVerified.lean) |
| Original finite prefix 7≤n≤48 | [`K6Prefix.finite_original`](LongCycleFinite/K6Prefix/All.lean) |
| Actual normalized analytic sign at predecessor zeros for all x≥0, p=n−1≥48 | [`SixCutoff.normalized_sign`](LongCycleBounds/SixCutoffVerified.lean) |
| Three analytic intervals, t=−exp(−x) | [compact](LongCycleBounds/SixCompactVerified.lean) · [middle](LongCycleBounds/SixMiddleSign.lean) · [exterior](LongCycleBounds/SixExteriorVerified.lean) |
| Original strict-excedance permutation sum | [`LongCycles.enumerator`](LongCycles/Statement.lean) |
| Weighted genuine rows and specialisation to the original | [`CycleProfile.row` and `row_zero`](LongCycleBounds/CycleProfile.lean) |
| From signs to the root lists with the true quotients and shared zero | [`CycleProfile.independent_interlacing_of_normalized_sign`](LongCycleBounds/CycleProfileIndependentReadout.lean) |

The lower and upper quotient degrees are n−3 and n−2. The finite endpoint assertions do not impose weights on the four short-cycle coordinates. The weighted result starts at upper size n=49 and is pointwise for each single admissible profile. The compiler prints actual types in the audit and the recorded proof closure includes the genuine permutation definitions.
