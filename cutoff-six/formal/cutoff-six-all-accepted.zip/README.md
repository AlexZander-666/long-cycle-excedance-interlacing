# Cutoff-six adjacent strict-excedance rows

The upper size is n and the pair is (n−1,n). With minimum cycle length six, the quotients by the common zero at t=0 have strictly interlacing simple negative zeros for every n≥7. The original rows weakly interlace. For n≥49 these conclusions hold throughout the closed cube of independent weights on cycle lengths two, three, four and five, with fixed points excluded and all cycles of length at least six weighted one. Both rows use the same profile.

`LongCycleBounds.SixCutoff.all_sizes` and `LongCycleBounds.SixCutoff.independent_weights` are the actual top-level declarations. The unweighted finite prefix covers upper sizes 7 through 48 with exact integer certificates. The analytic proof splits at x=13 and x=3√(n−1), where t=−exp(−x). [Exact theorem and input map](STATEMENT-MAP.md)

## Rebuild and replay

With elan, Git and Python 3, run from this extracted directory.

```sh
sha256sum -c SHA256SUMS
LEAN_NUM_THREADS=1 python3 -Bu verify_lean.py . SixCutoffAudit --jobs 4
```

The verifier creates a separate empty project, uses Lean v4.33.1 and the locked dependencies, fails on warnings, checks the listed transitive axioms, and independently replays each project module. Supply `--packages /path/to/.lake/packages` to reuse pinned third-party source checkouts and their compiled cache.
